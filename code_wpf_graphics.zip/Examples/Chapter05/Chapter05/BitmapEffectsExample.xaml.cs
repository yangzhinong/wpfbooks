using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Chapter05
{
    /// <summary>
    /// Interaction logic for BitmapEffectsExample.xaml
    /// </summary>

    public partial class BitmapEffectsExample : System.Windows.Window
    {

        public BitmapEffectsExample()
        {
            InitializeComponent();
        }

    }
}