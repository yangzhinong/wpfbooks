using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Chapter05
{
    public partial class RadialColormapBrushExample : System.Windows.Window
    {

        public RadialColormapBrushExample()
        {
            InitializeComponent();
            FillEllipses();
        }

        private void FillEllipses()
        {
            // Fill ellipse1 with "Spring" colormap:
            RadialColormapBrush brush = new RadialColormapBrush();
            ellipse1.Fill = brush.Spring();

            // Fill ellipse2 with "Summer" colormap:
            brush = new RadialColormapBrush();
            ellipse2.Fill = brush.Summer();

            // Fill ellipse3 with "Autumn" colormap:
            brush = new RadialColormapBrush();
            ellipse3.Fill = brush.Autumn();

            // Fill ellipse4 with "Winter" colormap:
            brush = new RadialColormapBrush();
            ellipse4.Fill = brush.Winter();

            // Fill ellipse5 with "Jet" colormap:
            brush = new RadialColormapBrush();
            ellipse5.Fill = brush.Jet();

            // Fill ellipse6 with "Gray" colormap:
            brush = new RadialColormapBrush();
            ellipse6.Fill = brush.Gray();

            // Fill ellipse7 with "Hot" colormap:
            brush = new RadialColormapBrush();
            ellipse7.Fill = brush.Hot();

            // Fill ellipse8 with "Cool" colormap:
            brush = new RadialColormapBrush();
            ellipse8.Fill = brush.Cool();
        }
    }
}