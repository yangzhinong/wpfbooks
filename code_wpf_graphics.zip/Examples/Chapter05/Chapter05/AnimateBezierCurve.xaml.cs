using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Chapter05
{
    public partial class AnimateBezierCurve : Window
    {
        DispatcherTimer dt = new DispatcherTimer();
        double alpha = 0;
        public AnimateBezierCurve()
        {
            InitializeComponent();
            dt.Interval = TimeSpan.FromMilliseconds(70);
            dt.Tick += new EventHandler(dt_Tick);
            dt.Start();
        }

        private void dt_Tick(object sender, EventArgs e)
        {
            alpha += 2;
            if (alpha >= 360)
                alpha = 0;
            double length = 150 + 100 * Math.Sin(alpha * Math.PI / 180);
            line1.EndPoint = new Point(length, 50);
            ellipse1.Center = new Point(length, 50);
            bezierSegment.Point1 = new Point(length, 50);
            line2.StartPoint = new Point(60, length);
            ellipse2.Center = new Point(60, length);
            bezierSegment.Point2 = new Point(60, length);
        }
    }
}