using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Chapter05
{
    /// <summary>
    /// Interaction logic for GradientBrushExample.xaml
    /// </summary>

    public partial class GradientBrushExample : System.Windows.Window
    {

        public GradientBrushExample()
        {
            InitializeComponent();
            AddMathFunction();
        }

        private void AddMathFunction()
        {
            // Create a cosine curve:
            ColormapBrush brush1 = new ColormapBrush();
            brush1.StartPoint = new Point(0, 0);
            brush1.EndPoint = new Point(0, 1);
            Polyline line1 = new Polyline();
            for (int i = 0; i < 200; i++)
            {
                double x = i;
                double y = 70 + 50 * Math.Sin(x / 4.0 / Math.PI);
                line1.Points.Add(new Point(x, y));
            }
            line1.Stroke = brush1.Spring();
            line1.StrokeThickness = 5;
            canvas1.Children.Add(line1);

            // Create a cosine curve:
            brush1 = new ColormapBrush();
            brush1.StartPoint = new Point(0, 1);
            brush1.EndPoint = new Point(0, 0);
            line1 = new Polyline();
            for (int i = 0; i < 200; i++)
            {
                double x = i;
                double y = 70 + 50 * Math.Cos(x / 4.0 / Math.PI);
                line1.Points.Add(new Point(x, y));
            }
            line1.Stroke = brush1.Jet();
            line1.StrokeThickness = 5;
            canvas1.Children.Add(line1);

           
        }
    }
}