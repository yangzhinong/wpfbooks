﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace Geometries
{
    public class IcosahedronGeometry
    {
        // Define private fields:
        private double sideLength = 1.0;
        private Point3D center = new Point3D();

        // Define public properties:
        public double SideLength
        {
            get { return sideLength; }
            set { sideLength = value; }
        }

        public Point3D Center
        {
            get { return center; }
            set { center = value; }
        }

        // Get-only property generates MeshGeometry3D object:
        public MeshGeometry3D Mesh3D
        {
            get { return GetMesh3D(); }
        }

        private MeshGeometry3D GetMesh3D()
        {
            MeshGeometry3D mesh = new MeshGeometry3D();
            Point3D[] pts = new Point3D[12];

            double phi = 0.5 * SideLength * (1 + Math.Sqrt(5.0));

            pts[0] = new Point3D(SideLength, 0, phi);
            pts[1] = new Point3D(-SideLength, 0, phi);
            pts[2] = new Point3D(0, phi, SideLength);
            pts[3] = new Point3D(0, -phi, SideLength);   
            pts[4] = new Point3D(phi, SideLength, 0);
            pts[5] = new Point3D(-phi, SideLength, 0);
            pts[6] = new Point3D(-phi, -SideLength, 0);
            pts[7] = new Point3D(phi, -SideLength, 0);
            pts[8] = new Point3D(0, phi, -SideLength);
            pts[9] = new Point3D(0, -phi, -SideLength);
            pts[10] = new Point3D(SideLength, 0, -phi);
            pts[11] = new Point3D(-SideLength, 0, -phi);

            for (int i = 0; i < 12; i++)
                pts[i] += (Vector3D)Center;

            // Face1:
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[3]);

            // Face2:
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[1]);
            
            // Face3:
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[7]);

            // Face4:
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[4]);

            // Face5:
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[2]);

            // Face6:
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[4]);

            // Face7:
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[8]);

            // Face8:
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[2]);

            // Face9:
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[5]);

            // Face10:
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[1]);

            // Face11:
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[6]);

            // Face12:
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[3]);

            // Face13:
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[9]);

            // Face14:
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[7]);

            // Face15:
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[10]);

            // Face16:
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[9]);

            // Face17:
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[10]);

            // Face18:
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[8]);

            // Face19:
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[5]);

            // Face20:
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[6]);

            for (int i = 0; i < 60; i++)
                mesh.TriangleIndices.Add(i);

            mesh.Freeze();
            return mesh;
        }
    }
}

