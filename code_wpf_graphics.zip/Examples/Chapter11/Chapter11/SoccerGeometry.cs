﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace Geometries
{
    public class SoccerGeometry
    {
        // Define private fields:
        private double sideLength = 1.0;
        private Point3D center = new Point3D();

        // Define public properties:
        public double SideLength
        {
            get { return sideLength; }
            set { sideLength = value; }
        }

        public Point3D Center
        {
            get { return center; }
            set { center = value; }
        }

        // Get-only property generates MeshGeometry3D object:
        public MeshGeometry3D Mesh3D
        {
            get { return GetMesh3D(); }
        }

        // Get-only property generates MeshGeometry3D object:
        public MeshGeometry3D PentagonMesh3D
        {
            get { return GetPentagonMesh3D(); }
        }

        // Get-only property generates MeshGeometry3D object:
        public MeshGeometry3D HexagonMesh3D
        {
            get { return GetHexagonMesh3D(); }
        }

        private MeshGeometry3D GetMesh3D()
        {
            MeshGeometry3D mesh = new MeshGeometry3D();

            Point3D[] pts = GetVortices();

            // Face1 (hexagon):
            mesh.Positions.Add(pts[29]);
            mesh.Positions.Add(pts[42]);
            mesh.Positions.Add(pts[46]);
            mesh.Positions.Add(pts[40]);
            mesh.Positions.Add(pts[28]);
            mesh.Positions.Add(pts[22]);

            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(1);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(4);
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(4);
            mesh.TriangleIndices.Add(5);

            // Face2 (hexagon):
            mesh.Positions.Add(pts[29]);
            mesh.Positions.Add(pts[22]);
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[14]);
            mesh.Positions.Add(pts[26]);

            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(7);
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(11);

            // Face3 (pentagon):
            mesh.Positions.Add(pts[29]);
            mesh.Positions.Add(pts[26]);
            mesh.Positions.Add(pts[34]);
            mesh.Positions.Add(pts[44]);
            mesh.Positions.Add(pts[42]);

            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(13);
            mesh.TriangleIndices.Add(14);
            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(14);
            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(16);

            // Face4 (hexagon):
            mesh.Positions.Add(pts[42]);
            mesh.Positions.Add(pts[44]);
            mesh.Positions.Add(pts[52]);
            mesh.Positions.Add(pts[58]);
            mesh.Positions.Add(pts[55]);
            mesh.Positions.Add(pts[46]);

            mesh.TriangleIndices.Add(17);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(19);
            mesh.TriangleIndices.Add(17);
            mesh.TriangleIndices.Add(19);
            mesh.TriangleIndices.Add(20);
            mesh.TriangleIndices.Add(17);
            mesh.TriangleIndices.Add(20);
            mesh.TriangleIndices.Add(21);
            mesh.TriangleIndices.Add(17);
            mesh.TriangleIndices.Add(21);
            mesh.TriangleIndices.Add(22);

            // Face5 (pentagon):
            mesh.Positions.Add(pts[22]);
            mesh.Positions.Add(pts[28]);
            mesh.Positions.Add(pts[20]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[11]);

            mesh.TriangleIndices.Add(23);
            mesh.TriangleIndices.Add(24);
            mesh.TriangleIndices.Add(25);
            mesh.TriangleIndices.Add(23);
            mesh.TriangleIndices.Add(25);
            mesh.TriangleIndices.Add(26);
            mesh.TriangleIndices.Add(23);
            mesh.TriangleIndices.Add(26);
            mesh.TriangleIndices.Add(27);

            // Face6 (hexagon):
            mesh.Positions.Add(pts[26]);
            mesh.Positions.Add(pts[14]);
            mesh.Positions.Add(pts[12]);
            mesh.Positions.Add(pts[21]);
            mesh.Positions.Add(pts[32]);
            mesh.Positions.Add(pts[34]);

            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(29);
            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(31);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(31);
            mesh.TriangleIndices.Add(32);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(32);
            mesh.TriangleIndices.Add(33);

            // Face7 (pentagon):
            mesh.Positions.Add(pts[46]);
            mesh.Positions.Add(pts[55]);
            mesh.Positions.Add(pts[53]);
            mesh.Positions.Add(pts[43]);
            mesh.Positions.Add(pts[40]);

            mesh.TriangleIndices.Add(34);
            mesh.TriangleIndices.Add(35);
            mesh.TriangleIndices.Add(36);
            mesh.TriangleIndices.Add(34);
            mesh.TriangleIndices.Add(36);
            mesh.TriangleIndices.Add(37);
            mesh.TriangleIndices.Add(34);
            mesh.TriangleIndices.Add(37);
            mesh.TriangleIndices.Add(38);

            // Face8 (hexagon):
            mesh.Positions.Add(pts[44]);
            mesh.Positions.Add(pts[34]);
            mesh.Positions.Add(pts[32]);
            mesh.Positions.Add(pts[41]);
            mesh.Positions.Add(pts[50]);
            mesh.Positions.Add(pts[52]);

            mesh.TriangleIndices.Add(39);
            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(41);
            mesh.TriangleIndices.Add(39);
            mesh.TriangleIndices.Add(41);
            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(39);
            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(43);
            mesh.TriangleIndices.Add(39);
            mesh.TriangleIndices.Add(43);
            mesh.TriangleIndices.Add(44);

            // Face9 (hexagon):
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[8]);

            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(46);
            mesh.TriangleIndices.Add(47);
            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(47);
            mesh.TriangleIndices.Add(48);
            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(48);
            mesh.TriangleIndices.Add(49);
            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(49);
            mesh.TriangleIndices.Add(50);

            // Face10 (hexagon):
            mesh.Positions.Add(pts[28]);
            mesh.Positions.Add(pts[40]);
            mesh.Positions.Add(pts[43]);
            mesh.Positions.Add(pts[36]);
            mesh.Positions.Add(pts[24]);
            mesh.Positions.Add(pts[20]);

            mesh.TriangleIndices.Add(51);
            mesh.TriangleIndices.Add(52);
            mesh.TriangleIndices.Add(53);
            mesh.TriangleIndices.Add(51);
            mesh.TriangleIndices.Add(53);
            mesh.TriangleIndices.Add(54);
            mesh.TriangleIndices.Add(51);
            mesh.TriangleIndices.Add(54);
            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(51);
            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(56);

            // Face11 (pentagon):
            mesh.Positions.Add(pts[14]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[12]);

            mesh.TriangleIndices.Add(57);
            mesh.TriangleIndices.Add(58);
            mesh.TriangleIndices.Add(59);
            mesh.TriangleIndices.Add(57);
            mesh.TriangleIndices.Add(59);
            mesh.TriangleIndices.Add(60);
            mesh.TriangleIndices.Add(57);
            mesh.TriangleIndices.Add(60);
            mesh.TriangleIndices.Add(61);

            // Face12 (hexagon):
            mesh.Positions.Add(pts[55]);
            mesh.Positions.Add(pts[58]);
            mesh.Positions.Add(pts[59]);
            mesh.Positions.Add(pts[57]);
            mesh.Positions.Add(pts[54]);
            mesh.Positions.Add(pts[53]);

            mesh.TriangleIndices.Add(62);
            mesh.TriangleIndices.Add(63);
            mesh.TriangleIndices.Add(64);
            mesh.TriangleIndices.Add(62);
            mesh.TriangleIndices.Add(64);
            mesh.TriangleIndices.Add(65);
            mesh.TriangleIndices.Add(62);
            mesh.TriangleIndices.Add(65);
            mesh.TriangleIndices.Add(66);
            mesh.TriangleIndices.Add(62);
            mesh.TriangleIndices.Add(66);
            mesh.TriangleIndices.Add(67);

            // Face13 (pentagon):
            mesh.Positions.Add(pts[52]);
            mesh.Positions.Add(pts[50]);
            mesh.Positions.Add(pts[56]);
            mesh.Positions.Add(pts[59]);
            mesh.Positions.Add(pts[58]);

            mesh.TriangleIndices.Add(68);
            mesh.TriangleIndices.Add(69);
            mesh.TriangleIndices.Add(70);
            mesh.TriangleIndices.Add(68);
            mesh.TriangleIndices.Add(70);
            mesh.TriangleIndices.Add(71);
            mesh.TriangleIndices.Add(68);
            mesh.TriangleIndices.Add(71);
            mesh.TriangleIndices.Add(72);

            // Face14 (hexagon):
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[20]);
            mesh.Positions.Add(pts[24]);
            mesh.Positions.Add(pts[18]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[3]);

            mesh.TriangleIndices.Add(73);
            mesh.TriangleIndices.Add(74);
            mesh.TriangleIndices.Add(75);
            mesh.TriangleIndices.Add(73);
            mesh.TriangleIndices.Add(75);
            mesh.TriangleIndices.Add(76);
            mesh.TriangleIndices.Add(73);
            mesh.TriangleIndices.Add(76);
            mesh.TriangleIndices.Add(77);
            mesh.TriangleIndices.Add(73);
            mesh.TriangleIndices.Add(77);
            mesh.TriangleIndices.Add(78);

            // Face15 (pentagon):
            mesh.Positions.Add(pts[32]);
            mesh.Positions.Add(pts[21]);
            mesh.Positions.Add(pts[23]);
            mesh.Positions.Add(pts[35]);
            mesh.Positions.Add(pts[41]);

            mesh.TriangleIndices.Add(79);
            mesh.TriangleIndices.Add(80);
            mesh.TriangleIndices.Add(81);
            mesh.TriangleIndices.Add(79);
            mesh.TriangleIndices.Add(81);
            mesh.TriangleIndices.Add(82);
            mesh.TriangleIndices.Add(79);
            mesh.TriangleIndices.Add(82);
            mesh.TriangleIndices.Add(83);

            // Face16 (hexagon):
            mesh.Positions.Add(pts[12]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[16]);
            mesh.Positions.Add(pts[23]);
            mesh.Positions.Add(pts[21]);

            mesh.TriangleIndices.Add(84);
            mesh.TriangleIndices.Add(85);
            mesh.TriangleIndices.Add(86);
            mesh.TriangleIndices.Add(84);
            mesh.TriangleIndices.Add(86);
            mesh.TriangleIndices.Add(87);
            mesh.TriangleIndices.Add(84);
            mesh.TriangleIndices.Add(87);
            mesh.TriangleIndices.Add(88);
            mesh.TriangleIndices.Add(84);
            mesh.TriangleIndices.Add(88);
            mesh.TriangleIndices.Add(89);

            // Face17 (hexagon):
            mesh.Positions.Add(pts[53]);
            mesh.Positions.Add(pts[54]);
            mesh.Positions.Add(pts[47]);
            mesh.Positions.Add(pts[38]);
            mesh.Positions.Add(pts[36]);
            mesh.Positions.Add(pts[43]);

            mesh.TriangleIndices.Add(90);
            mesh.TriangleIndices.Add(91);
            mesh.TriangleIndices.Add(92);
            mesh.TriangleIndices.Add(90);
            mesh.TriangleIndices.Add(92);
            mesh.TriangleIndices.Add(93);
            mesh.TriangleIndices.Add(90);
            mesh.TriangleIndices.Add(93);
            mesh.TriangleIndices.Add(94);
            mesh.TriangleIndices.Add(90);
            mesh.TriangleIndices.Add(94);
            mesh.TriangleIndices.Add(95);

            // Face18 (hexagon):
            mesh.Positions.Add(pts[50]);
            mesh.Positions.Add(pts[41]);
            mesh.Positions.Add(pts[35]);
            mesh.Positions.Add(pts[39]);
            mesh.Positions.Add(pts[49]);
            mesh.Positions.Add(pts[56]);

            mesh.TriangleIndices.Add(96);
            mesh.TriangleIndices.Add(97);
            mesh.TriangleIndices.Add(98);
            mesh.TriangleIndices.Add(96);
            mesh.TriangleIndices.Add(98);
            mesh.TriangleIndices.Add(99);
            mesh.TriangleIndices.Add(96);
            mesh.TriangleIndices.Add(99);
            mesh.TriangleIndices.Add(100);
            mesh.TriangleIndices.Add(96);
            mesh.TriangleIndices.Add(100);
            mesh.TriangleIndices.Add(101);

            // Face19 (pentagon):
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[0]);

            mesh.TriangleIndices.Add(102);
            mesh.TriangleIndices.Add(103);
            mesh.TriangleIndices.Add(104);
            mesh.TriangleIndices.Add(102);
            mesh.TriangleIndices.Add(104);
            mesh.TriangleIndices.Add(105);
            mesh.TriangleIndices.Add(102);
            mesh.TriangleIndices.Add(105);
            mesh.TriangleIndices.Add(106);

            // Face20 (hexagon):
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[5]);

            mesh.TriangleIndices.Add(107);
            mesh.TriangleIndices.Add(108);
            mesh.TriangleIndices.Add(109);
            mesh.TriangleIndices.Add(107);
            mesh.TriangleIndices.Add(109);
            mesh.TriangleIndices.Add(110);
            mesh.TriangleIndices.Add(107);
            mesh.TriangleIndices.Add(110);
            mesh.TriangleIndices.Add(111);
            mesh.TriangleIndices.Add(107);
            mesh.TriangleIndices.Add(111);
            mesh.TriangleIndices.Add(112);

            // Face21 (pentagon):
            mesh.Positions.Add(pts[24]);
            mesh.Positions.Add(pts[36]);
            mesh.Positions.Add(pts[38]);
            mesh.Positions.Add(pts[27]);
            mesh.Positions.Add(pts[18]);

            mesh.TriangleIndices.Add(113);
            mesh.TriangleIndices.Add(114);
            mesh.TriangleIndices.Add(115);
            mesh.TriangleIndices.Add(113);
            mesh.TriangleIndices.Add(115);
            mesh.TriangleIndices.Add(116);
            mesh.TriangleIndices.Add(113);
            mesh.TriangleIndices.Add(116);
            mesh.TriangleIndices.Add(117);

            // Face22 (pentagon):
            mesh.Positions.Add(pts[54]);
            mesh.Positions.Add(pts[57]);
            mesh.Positions.Add(pts[51]);
            mesh.Positions.Add(pts[45]);
            mesh.Positions.Add(pts[47]);

            mesh.TriangleIndices.Add(118);
            mesh.TriangleIndices.Add(119);
            mesh.TriangleIndices.Add(120);
            mesh.TriangleIndices.Add(118);
            mesh.TriangleIndices.Add(120);
            mesh.TriangleIndices.Add(121);
            mesh.TriangleIndices.Add(118);
            mesh.TriangleIndices.Add(121);
            mesh.TriangleIndices.Add(122);

            // Face23 (hexagon):
            mesh.Positions.Add(pts[59]);
            mesh.Positions.Add(pts[56]);
            mesh.Positions.Add(pts[49]);
            mesh.Positions.Add(pts[48]);
            mesh.Positions.Add(pts[51]);
            mesh.Positions.Add(pts[57]);

            mesh.TriangleIndices.Add(123);
            mesh.TriangleIndices.Add(124);
            mesh.TriangleIndices.Add(125);
            mesh.TriangleIndices.Add(123);
            mesh.TriangleIndices.Add(125);
            mesh.TriangleIndices.Add(126);
            mesh.TriangleIndices.Add(123);
            mesh.TriangleIndices.Add(126);
            mesh.TriangleIndices.Add(127);
            mesh.TriangleIndices.Add(123);
            mesh.TriangleIndices.Add(127);
            mesh.TriangleIndices.Add(128);

            // Face24 (hexagon):
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[18]);
            mesh.Positions.Add(pts[27]);
            mesh.Positions.Add(pts[25]);
            mesh.Positions.Add(pts[15]);
            mesh.Positions.Add(pts[7]);

            mesh.TriangleIndices.Add(129);
            mesh.TriangleIndices.Add(130);
            mesh.TriangleIndices.Add(131);
            mesh.TriangleIndices.Add(129);
            mesh.TriangleIndices.Add(131);
            mesh.TriangleIndices.Add(132);
            mesh.TriangleIndices.Add(129);
            mesh.TriangleIndices.Add(132);
            mesh.TriangleIndices.Add(133);
            mesh.TriangleIndices.Add(129);
            mesh.TriangleIndices.Add(133);
            mesh.TriangleIndices.Add(134);

            // Face25 (hexagon):
            mesh.Positions.Add(pts[35]);
            mesh.Positions.Add(pts[23]);
            mesh.Positions.Add(pts[16]);
            mesh.Positions.Add(pts[19]);
            mesh.Positions.Add(pts[31]);
            mesh.Positions.Add(pts[39]);

            mesh.TriangleIndices.Add(135);
            mesh.TriangleIndices.Add(136);
            mesh.TriangleIndices.Add(137);
            mesh.TriangleIndices.Add(135);
            mesh.TriangleIndices.Add(137);
            mesh.TriangleIndices.Add(138);
            mesh.TriangleIndices.Add(135);
            mesh.TriangleIndices.Add(138);
            mesh.TriangleIndices.Add(139);
            mesh.TriangleIndices.Add(135);
            mesh.TriangleIndices.Add(139);
            mesh.TriangleIndices.Add(140);

            // Face26 (pentagon):
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[19]);
            mesh.Positions.Add(pts[16]);

            mesh.TriangleIndices.Add(141);
            mesh.TriangleIndices.Add(142);
            mesh.TriangleIndices.Add(143);
            mesh.TriangleIndices.Add(141);
            mesh.TriangleIndices.Add(143);
            mesh.TriangleIndices.Add(144);
            mesh.TriangleIndices.Add(141);
            mesh.TriangleIndices.Add(144);
            mesh.TriangleIndices.Add(145);

            // Face27 (hexagon):
            mesh.Positions.Add(pts[47]);
            mesh.Positions.Add(pts[45]);
            mesh.Positions.Add(pts[33]);
            mesh.Positions.Add(pts[25]);
            mesh.Positions.Add(pts[27]);
            mesh.Positions.Add(pts[38]);

            mesh.TriangleIndices.Add(146);
            mesh.TriangleIndices.Add(147);
            mesh.TriangleIndices.Add(148);
            mesh.TriangleIndices.Add(146);
            mesh.TriangleIndices.Add(148);
            mesh.TriangleIndices.Add(149);
            mesh.TriangleIndices.Add(146);
            mesh.TriangleIndices.Add(149);
            mesh.TriangleIndices.Add(150);
            mesh.TriangleIndices.Add(146);
            mesh.TriangleIndices.Add(150);
            mesh.TriangleIndices.Add(151);

            // Face28 (pentagon):
            mesh.Positions.Add(pts[49]);
            mesh.Positions.Add(pts[39]);
            mesh.Positions.Add(pts[31]);
            mesh.Positions.Add(pts[37]);
            mesh.Positions.Add(pts[48]);

            mesh.TriangleIndices.Add(152);
            mesh.TriangleIndices.Add(153);
            mesh.TriangleIndices.Add(154);
            mesh.TriangleIndices.Add(152);
            mesh.TriangleIndices.Add(154);
            mesh.TriangleIndices.Add(155);
            mesh.TriangleIndices.Add(152);
            mesh.TriangleIndices.Add(155);
            mesh.TriangleIndices.Add(156);

            // Face29 (hexagon):
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[15]);
            mesh.Positions.Add(pts[17]);
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[1]);

            mesh.TriangleIndices.Add(157);
            mesh.TriangleIndices.Add(158);
            mesh.TriangleIndices.Add(159);
            mesh.TriangleIndices.Add(157);
            mesh.TriangleIndices.Add(159);
            mesh.TriangleIndices.Add(160);
            mesh.TriangleIndices.Add(157);
            mesh.TriangleIndices.Add(160);
            mesh.TriangleIndices.Add(161);
            mesh.TriangleIndices.Add(157);
            mesh.TriangleIndices.Add(161);
            mesh.TriangleIndices.Add(162);

            // Face30 (hexagon):
            mesh.Positions.Add(pts[45]);
            mesh.Positions.Add(pts[51]);
            mesh.Positions.Add(pts[48]);
            mesh.Positions.Add(pts[37]);
            mesh.Positions.Add(pts[30]);
            mesh.Positions.Add(pts[33]);

            mesh.TriangleIndices.Add(163);
            mesh.TriangleIndices.Add(164);
            mesh.TriangleIndices.Add(165);
            mesh.TriangleIndices.Add(163);
            mesh.TriangleIndices.Add(165);
            mesh.TriangleIndices.Add(166);
            mesh.TriangleIndices.Add(163);
            mesh.TriangleIndices.Add(166);
            mesh.TriangleIndices.Add(167);
            mesh.TriangleIndices.Add(163);
            mesh.TriangleIndices.Add(167);
            mesh.TriangleIndices.Add(168);

            // Face31 (pentagon):
            mesh.Positions.Add(pts[15]);
            mesh.Positions.Add(pts[25]);
            mesh.Positions.Add(pts[33]);
            mesh.Positions.Add(pts[30]);
            mesh.Positions.Add(pts[17]);

            mesh.TriangleIndices.Add(169);
            mesh.TriangleIndices.Add(170);
            mesh.TriangleIndices.Add(171);
            mesh.TriangleIndices.Add(169);
            mesh.TriangleIndices.Add(171);
            mesh.TriangleIndices.Add(172);
            mesh.TriangleIndices.Add(169);
            mesh.TriangleIndices.Add(172);
            mesh.TriangleIndices.Add(173);

            // Face32 (hexagon):
            mesh.Positions.Add(pts[31]);
            mesh.Positions.Add(pts[19]);
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[17]);
            mesh.Positions.Add(pts[30]);
            mesh.Positions.Add(pts[37]);

            mesh.TriangleIndices.Add(174);
            mesh.TriangleIndices.Add(175);
            mesh.TriangleIndices.Add(176);
            mesh.TriangleIndices.Add(174);
            mesh.TriangleIndices.Add(176);
            mesh.TriangleIndices.Add(177);
            mesh.TriangleIndices.Add(174);
            mesh.TriangleIndices.Add(177);
            mesh.TriangleIndices.Add(178);
            mesh.TriangleIndices.Add(174);
            mesh.TriangleIndices.Add(178);
            mesh.TriangleIndices.Add(179);

            mesh.Freeze();
            return mesh;
        }

        private MeshGeometry3D GetHexagonMesh3D()
        {
            MeshGeometry3D mesh = new MeshGeometry3D();

            Point3D[] pts = GetVortices();

            // Face1 (hexagon):
            mesh.Positions.Add(pts[29]);
            mesh.Positions.Add(pts[42]);
            mesh.Positions.Add(pts[46]);
            mesh.Positions.Add(pts[40]);
            mesh.Positions.Add(pts[28]);
            mesh.Positions.Add(pts[22]);

            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(1);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(4);
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(4);
            mesh.TriangleIndices.Add(5);

            // Face2 (hexagon):
            mesh.Positions.Add(pts[29]);
            mesh.Positions.Add(pts[22]);
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[14]);
            mesh.Positions.Add(pts[26]);

            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(7);
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(11);

            // Face3 (hexagon):
            mesh.Positions.Add(pts[42]);
            mesh.Positions.Add(pts[44]);
            mesh.Positions.Add(pts[52]);
            mesh.Positions.Add(pts[58]);
            mesh.Positions.Add(pts[55]);
            mesh.Positions.Add(pts[46]);

            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(13);
            mesh.TriangleIndices.Add(14);
            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(14);
            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(16);
            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(16);
            mesh.TriangleIndices.Add(17);

            // Face4 (hexagon):
            mesh.Positions.Add(pts[26]);
            mesh.Positions.Add(pts[14]);
            mesh.Positions.Add(pts[12]);
            mesh.Positions.Add(pts[21]);
            mesh.Positions.Add(pts[32]);
            mesh.Positions.Add(pts[34]);

            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(19);
            mesh.TriangleIndices.Add(20);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(20);
            mesh.TriangleIndices.Add(21);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(21);
            mesh.TriangleIndices.Add(22);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(22);
            mesh.TriangleIndices.Add(23);

            // Face5 (hexagon):
            mesh.Positions.Add(pts[44]);
            mesh.Positions.Add(pts[34]);
            mesh.Positions.Add(pts[32]);
            mesh.Positions.Add(pts[41]);
            mesh.Positions.Add(pts[50]);
            mesh.Positions.Add(pts[52]);

            mesh.TriangleIndices.Add(24);
            mesh.TriangleIndices.Add(25);
            mesh.TriangleIndices.Add(26);
            mesh.TriangleIndices.Add(24);
            mesh.TriangleIndices.Add(26);
            mesh.TriangleIndices.Add(27);
            mesh.TriangleIndices.Add(24);
            mesh.TriangleIndices.Add(27);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(24);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(29);

            // Face6 (hexagon):
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[8]);

            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(31);
            mesh.TriangleIndices.Add(32);
            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(32);
            mesh.TriangleIndices.Add(33);
            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(33);
            mesh.TriangleIndices.Add(34);
            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(34);
            mesh.TriangleIndices.Add(35);

            // Face7 (hexagon):
            mesh.Positions.Add(pts[28]);
            mesh.Positions.Add(pts[40]);
            mesh.Positions.Add(pts[43]);
            mesh.Positions.Add(pts[36]);
            mesh.Positions.Add(pts[24]);
            mesh.Positions.Add(pts[20]);

            mesh.TriangleIndices.Add(36);
            mesh.TriangleIndices.Add(37);
            mesh.TriangleIndices.Add(38);
            mesh.TriangleIndices.Add(36);
            mesh.TriangleIndices.Add(38);
            mesh.TriangleIndices.Add(39);
            mesh.TriangleIndices.Add(36);
            mesh.TriangleIndices.Add(39);
            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(36);
            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(41);

            // Face8 (hexagon):
            mesh.Positions.Add(pts[55]);
            mesh.Positions.Add(pts[58]);
            mesh.Positions.Add(pts[59]);
            mesh.Positions.Add(pts[57]);
            mesh.Positions.Add(pts[54]);
            mesh.Positions.Add(pts[53]);

            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(43);
            mesh.TriangleIndices.Add(44);
            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(44);
            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(46);
            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(46);
            mesh.TriangleIndices.Add(47);

            // Face9 (hexagon):
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[20]);
            mesh.Positions.Add(pts[24]);
            mesh.Positions.Add(pts[18]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[3]);

            mesh.TriangleIndices.Add(48);
            mesh.TriangleIndices.Add(49);
            mesh.TriangleIndices.Add(50);
            mesh.TriangleIndices.Add(48);
            mesh.TriangleIndices.Add(50);
            mesh.TriangleIndices.Add(51);
            mesh.TriangleIndices.Add(48);
            mesh.TriangleIndices.Add(51);
            mesh.TriangleIndices.Add(52);
            mesh.TriangleIndices.Add(48);
            mesh.TriangleIndices.Add(52);
            mesh.TriangleIndices.Add(53);

            // Face10 (hexagon):
            mesh.Positions.Add(pts[12]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[16]);
            mesh.Positions.Add(pts[23]);
            mesh.Positions.Add(pts[21]);

            mesh.TriangleIndices.Add(54);
            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(56);
            mesh.TriangleIndices.Add(54);
            mesh.TriangleIndices.Add(56);
            mesh.TriangleIndices.Add(57);
            mesh.TriangleIndices.Add(54);
            mesh.TriangleIndices.Add(57);
            mesh.TriangleIndices.Add(58);
            mesh.TriangleIndices.Add(54);
            mesh.TriangleIndices.Add(58);
            mesh.TriangleIndices.Add(59);

            // Face11 (hexagon):
            mesh.Positions.Add(pts[53]);
            mesh.Positions.Add(pts[54]);
            mesh.Positions.Add(pts[47]);
            mesh.Positions.Add(pts[38]);
            mesh.Positions.Add(pts[36]);
            mesh.Positions.Add(pts[43]);

            mesh.TriangleIndices.Add(60);
            mesh.TriangleIndices.Add(61);
            mesh.TriangleIndices.Add(62);
            mesh.TriangleIndices.Add(60);
            mesh.TriangleIndices.Add(62);
            mesh.TriangleIndices.Add(63);
            mesh.TriangleIndices.Add(60);
            mesh.TriangleIndices.Add(63);
            mesh.TriangleIndices.Add(64);
            mesh.TriangleIndices.Add(60);
            mesh.TriangleIndices.Add(64);
            mesh.TriangleIndices.Add(65);

            // Face12 (hexagon):
            mesh.Positions.Add(pts[50]);
            mesh.Positions.Add(pts[41]);
            mesh.Positions.Add(pts[35]);
            mesh.Positions.Add(pts[39]);
            mesh.Positions.Add(pts[49]);
            mesh.Positions.Add(pts[56]);

            mesh.TriangleIndices.Add(66);
            mesh.TriangleIndices.Add(67);
            mesh.TriangleIndices.Add(68);
            mesh.TriangleIndices.Add(66);
            mesh.TriangleIndices.Add(68);
            mesh.TriangleIndices.Add(69);
            mesh.TriangleIndices.Add(66);
            mesh.TriangleIndices.Add(69);
            mesh.TriangleIndices.Add(70);
            mesh.TriangleIndices.Add(66);
            mesh.TriangleIndices.Add(70);
            mesh.TriangleIndices.Add(71);

            // Face13 (hexagon):
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[5]);

            mesh.TriangleIndices.Add(72);
            mesh.TriangleIndices.Add(73);
            mesh.TriangleIndices.Add(74);
            mesh.TriangleIndices.Add(72);
            mesh.TriangleIndices.Add(74);
            mesh.TriangleIndices.Add(75);
            mesh.TriangleIndices.Add(72);
            mesh.TriangleIndices.Add(75);
            mesh.TriangleIndices.Add(76);
            mesh.TriangleIndices.Add(72);
            mesh.TriangleIndices.Add(76);
            mesh.TriangleIndices.Add(77);

            // Face14 (hexagon):
            mesh.Positions.Add(pts[59]);
            mesh.Positions.Add(pts[56]);
            mesh.Positions.Add(pts[49]);
            mesh.Positions.Add(pts[48]);
            mesh.Positions.Add(pts[51]);
            mesh.Positions.Add(pts[57]);

            mesh.TriangleIndices.Add(78);
            mesh.TriangleIndices.Add(79);
            mesh.TriangleIndices.Add(80);
            mesh.TriangleIndices.Add(78);
            mesh.TriangleIndices.Add(80);
            mesh.TriangleIndices.Add(81);
            mesh.TriangleIndices.Add(78);
            mesh.TriangleIndices.Add(81);
            mesh.TriangleIndices.Add(82);
            mesh.TriangleIndices.Add(78);
            mesh.TriangleIndices.Add(82);
            mesh.TriangleIndices.Add(83);

            // Face15 (hexagon):
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[18]);
            mesh.Positions.Add(pts[27]);
            mesh.Positions.Add(pts[25]);
            mesh.Positions.Add(pts[15]);
            mesh.Positions.Add(pts[7]);

            mesh.TriangleIndices.Add(84);
            mesh.TriangleIndices.Add(85);
            mesh.TriangleIndices.Add(86);
            mesh.TriangleIndices.Add(84);
            mesh.TriangleIndices.Add(86);
            mesh.TriangleIndices.Add(87);
            mesh.TriangleIndices.Add(84);
            mesh.TriangleIndices.Add(87);
            mesh.TriangleIndices.Add(88);
            mesh.TriangleIndices.Add(84);
            mesh.TriangleIndices.Add(88);
            mesh.TriangleIndices.Add(89);

            // Face16 (hexagon):
            mesh.Positions.Add(pts[35]);
            mesh.Positions.Add(pts[23]);
            mesh.Positions.Add(pts[16]);
            mesh.Positions.Add(pts[19]);
            mesh.Positions.Add(pts[31]);
            mesh.Positions.Add(pts[39]);

            mesh.TriangleIndices.Add(90);
            mesh.TriangleIndices.Add(91);
            mesh.TriangleIndices.Add(92);
            mesh.TriangleIndices.Add(90);
            mesh.TriangleIndices.Add(92);
            mesh.TriangleIndices.Add(93);
            mesh.TriangleIndices.Add(90);
            mesh.TriangleIndices.Add(93);
            mesh.TriangleIndices.Add(94);
            mesh.TriangleIndices.Add(90);
            mesh.TriangleIndices.Add(94);
            mesh.TriangleIndices.Add(95);

            // Face17 (hexagon):
            mesh.Positions.Add(pts[47]);
            mesh.Positions.Add(pts[45]);
            mesh.Positions.Add(pts[33]);
            mesh.Positions.Add(pts[25]);
            mesh.Positions.Add(pts[27]);
            mesh.Positions.Add(pts[38]);

            mesh.TriangleIndices.Add(96);
            mesh.TriangleIndices.Add(97);
            mesh.TriangleIndices.Add(98);
            mesh.TriangleIndices.Add(96);
            mesh.TriangleIndices.Add(98);
            mesh.TriangleIndices.Add(99);
            mesh.TriangleIndices.Add(96);
            mesh.TriangleIndices.Add(99);
            mesh.TriangleIndices.Add(100);
            mesh.TriangleIndices.Add(96);
            mesh.TriangleIndices.Add(100);
            mesh.TriangleIndices.Add(101);

            // Face18 (hexagon):
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[15]);
            mesh.Positions.Add(pts[17]);
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[1]);

            mesh.TriangleIndices.Add(102);
            mesh.TriangleIndices.Add(103);
            mesh.TriangleIndices.Add(104);
            mesh.TriangleIndices.Add(102);
            mesh.TriangleIndices.Add(104);
            mesh.TriangleIndices.Add(105);
            mesh.TriangleIndices.Add(102);
            mesh.TriangleIndices.Add(105);
            mesh.TriangleIndices.Add(106);
            mesh.TriangleIndices.Add(102);
            mesh.TriangleIndices.Add(106);
            mesh.TriangleIndices.Add(107);

            // Face19 (hexagon):
            mesh.Positions.Add(pts[45]);
            mesh.Positions.Add(pts[51]);
            mesh.Positions.Add(pts[48]);
            mesh.Positions.Add(pts[37]);
            mesh.Positions.Add(pts[30]);
            mesh.Positions.Add(pts[33]);

            mesh.TriangleIndices.Add(108);
            mesh.TriangleIndices.Add(109);
            mesh.TriangleIndices.Add(110);
            mesh.TriangleIndices.Add(108);
            mesh.TriangleIndices.Add(110);
            mesh.TriangleIndices.Add(111);
            mesh.TriangleIndices.Add(108);
            mesh.TriangleIndices.Add(111);
            mesh.TriangleIndices.Add(112);
            mesh.TriangleIndices.Add(108);
            mesh.TriangleIndices.Add(112);
            mesh.TriangleIndices.Add(113);

            // Face20 (hexagon):
            mesh.Positions.Add(pts[31]);
            mesh.Positions.Add(pts[19]);
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[17]);
            mesh.Positions.Add(pts[30]);
            mesh.Positions.Add(pts[37]);

            mesh.TriangleIndices.Add(114);
            mesh.TriangleIndices.Add(115);
            mesh.TriangleIndices.Add(116);
            mesh.TriangleIndices.Add(114);
            mesh.TriangleIndices.Add(116);
            mesh.TriangleIndices.Add(117);
            mesh.TriangleIndices.Add(114);
            mesh.TriangleIndices.Add(117);
            mesh.TriangleIndices.Add(118);
            mesh.TriangleIndices.Add(114);
            mesh.TriangleIndices.Add(118);
            mesh.TriangleIndices.Add(119);

            mesh.Freeze();
            return mesh;
        }

        private MeshGeometry3D GetPentagonMesh3D()
        {
            MeshGeometry3D mesh = new MeshGeometry3D();

            Point3D[] pts = GetVortices();

            // Face1 (pentagon):
            mesh.Positions.Add(pts[29]);
            mesh.Positions.Add(pts[26]);
            mesh.Positions.Add(pts[34]);
            mesh.Positions.Add(pts[44]);
            mesh.Positions.Add(pts[42]);

            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(1);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(4);

            // Face2 (pentagon):
            mesh.Positions.Add(pts[22]);
            mesh.Positions.Add(pts[28]);
            mesh.Positions.Add(pts[20]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[11]);

            mesh.TriangleIndices.Add(5);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(7);
            mesh.TriangleIndices.Add(5);
            mesh.TriangleIndices.Add(7);
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(5);
            mesh.TriangleIndices.Add(8);
            mesh.TriangleIndices.Add(9);

            // Face3 (pentagon):
            mesh.Positions.Add(pts[46]);
            mesh.Positions.Add(pts[55]);
            mesh.Positions.Add(pts[53]);
            mesh.Positions.Add(pts[43]);
            mesh.Positions.Add(pts[40]);

            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(11);
            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(12);
            mesh.TriangleIndices.Add(13);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(13);
            mesh.TriangleIndices.Add(14);

            // Face4 (pentagon):
            mesh.Positions.Add(pts[14]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[12]);

            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(16);
            mesh.TriangleIndices.Add(17);
            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(17);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(19);

            // Face5 (pentagon):
            mesh.Positions.Add(pts[52]);
            mesh.Positions.Add(pts[50]);
            mesh.Positions.Add(pts[56]);
            mesh.Positions.Add(pts[59]);
            mesh.Positions.Add(pts[58]);

            mesh.TriangleIndices.Add(20);
            mesh.TriangleIndices.Add(21);
            mesh.TriangleIndices.Add(22);
            mesh.TriangleIndices.Add(20);
            mesh.TriangleIndices.Add(22);
            mesh.TriangleIndices.Add(23);
            mesh.TriangleIndices.Add(20);
            mesh.TriangleIndices.Add(23);
            mesh.TriangleIndices.Add(24);

            // Face6 (pentagon):
            mesh.Positions.Add(pts[32]);
            mesh.Positions.Add(pts[21]);
            mesh.Positions.Add(pts[23]);
            mesh.Positions.Add(pts[35]);
            mesh.Positions.Add(pts[41]);

            mesh.TriangleIndices.Add(25);
            mesh.TriangleIndices.Add(26);
            mesh.TriangleIndices.Add(27);
            mesh.TriangleIndices.Add(25);
            mesh.TriangleIndices.Add(27);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(25);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(29);

            // Face7 (pentagon):
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[0]);

            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(31);
            mesh.TriangleIndices.Add(32);
            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(32);
            mesh.TriangleIndices.Add(33);
            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(33);
            mesh.TriangleIndices.Add(34);

            // Face8 (pentagon):
            mesh.Positions.Add(pts[24]);
            mesh.Positions.Add(pts[36]);
            mesh.Positions.Add(pts[38]);
            mesh.Positions.Add(pts[27]);
            mesh.Positions.Add(pts[18]);

            mesh.TriangleIndices.Add(35);
            mesh.TriangleIndices.Add(36);
            mesh.TriangleIndices.Add(37);
            mesh.TriangleIndices.Add(35);
            mesh.TriangleIndices.Add(37);
            mesh.TriangleIndices.Add(38);
            mesh.TriangleIndices.Add(35);
            mesh.TriangleIndices.Add(38);
            mesh.TriangleIndices.Add(39);

            // Face9 (pentagon):
            mesh.Positions.Add(pts[54]);
            mesh.Positions.Add(pts[57]);
            mesh.Positions.Add(pts[51]);
            mesh.Positions.Add(pts[45]);
            mesh.Positions.Add(pts[47]);

            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(41);
            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(43);
            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(43);
            mesh.TriangleIndices.Add(44);

            // Face10 (pentagon):
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[19]);
            mesh.Positions.Add(pts[16]);

            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(46);
            mesh.TriangleIndices.Add(47);
            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(47);
            mesh.TriangleIndices.Add(48);
            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(48);
            mesh.TriangleIndices.Add(49);

            // Face11 (pentagon):
            mesh.Positions.Add(pts[49]);
            mesh.Positions.Add(pts[39]);
            mesh.Positions.Add(pts[31]);
            mesh.Positions.Add(pts[37]);
            mesh.Positions.Add(pts[48]);

            mesh.TriangleIndices.Add(50);
            mesh.TriangleIndices.Add(51);
            mesh.TriangleIndices.Add(52);
            mesh.TriangleIndices.Add(50);
            mesh.TriangleIndices.Add(52);
            mesh.TriangleIndices.Add(53);
            mesh.TriangleIndices.Add(50);
            mesh.TriangleIndices.Add(53);
            mesh.TriangleIndices.Add(54);

            // Face12 (pentagon):
            mesh.Positions.Add(pts[15]);
            mesh.Positions.Add(pts[25]);
            mesh.Positions.Add(pts[33]);
            mesh.Positions.Add(pts[30]);
            mesh.Positions.Add(pts[17]);

            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(56);
            mesh.TriangleIndices.Add(57);
            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(57);
            mesh.TriangleIndices.Add(58);
            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(58);
            mesh.TriangleIndices.Add(59);

            mesh.Freeze();
            return mesh;
        }

        private Point3D[] GetVortices()
        {
            Point3D[] pts = new Point3D[60];

            pts[0] = new Point3D(-1.00714, 0.153552, 0.067258);
            pts[1] = new Point3D(-0.960284, 0.0848813, -0.33629);
            pts[2] = new Point3D(-0.95172, -0.153552, 0.33629);
            pts[3] = new Point3D(-0.860021, 0.529326, 0.150394);
            pts[4] = new Point3D(-0.858, -0.290893, -0.470806);
            pts[5] = new Point3D(-0.849436, -0.529326, 0.201774);
            pts[6] = new Point3D(-0.802576, -0.597996, -0.201774);
            pts[7] = new Point3D(-0.7842, 0.418215, -0.502561);
            pts[8] = new Point3D(-0.749174, -0.0848813, 0.688458);
            pts[9] = new Point3D(-0.722234, 0.692896, -0.201774);
            pts[10] = new Point3D(-0.657475, 0.597996, 0.502561);
            pts[11] = new Point3D(-0.602051, 0.290893, 0.771593);
            pts[12] = new Point3D(-0.583675, -0.692896, 0.470806);
            pts[13] = new Point3D(-0.579632, -0.333333, -0.771593);
            pts[14] = new Point3D(-0.52171, -0.418215, 0.771593);
            pts[15] = new Point3D(-0.505832, 0.375774, -0.803348);
            pts[16] = new Point3D(-0.489955, -0.830237, -0.33629);
            pts[17] = new Point3D(-0.403548, 0.0, -0.937864);
            pts[18] = new Point3D(-0.381901, 0.925138, -0.201774);
            pts[19] = new Point3D(-0.352168, -0.666667, -0.688458);
            pts[20] = new Point3D(-0.317142, 0.830237, 0.502561);
            pts[21] = new Point3D(-0.271054, -0.925138, 0.33629);
            pts[22] = new Point3D(-0.227464, 0.333333, 0.937864);
            pts[23] = new Point3D(-0.224193, -0.993808, -0.067258);
            pts[24] = new Point3D(-0.179355, 0.993808, 0.150394);
            pts[25] = new Point3D(-0.165499, 0.608015, -0.803348);
            pts[26] = new Point3D(-0.147123, -0.375774, 0.937864);
            pts[27] = new Point3D(-0.103533, 0.882697, -0.502561);
            pts[28] = new Point3D(-0.0513806, 0.666667, 0.771593);
            pts[29] = new Point3D(0.0000000, 0.0, 1.021);
            pts[30] = new Point3D(0.0000000, 0.0, -1.021);
            pts[31] = new Point3D(0.0513806, -0.666667, -0.771593);
            pts[32] = new Point3D(0.103533, -0.882697, 0.502561);
            pts[33] = new Point3D(0.147123, 0.375774, -0.937864);
            pts[34] = new Point3D(0.165499, -0.608015, 0.803348);
            pts[35] = new Point3D(0.179355, -0.993808, -0.150394);
            pts[36] = new Point3D(0.224193, 0.993808, 0.067258);
            pts[37] = new Point3D(0.227464, -0.333333, -0.937864);
            pts[38] = new Point3D(0.271054, 0.925138, -0.33629);
            pts[39] = new Point3D(0.317142, -0.830237, -0.502561);
            pts[40] = new Point3D(0.352168, 0.666667, 0.688458);
            pts[41] = new Point3D(0.381901, -0.925138, 0.201774);
            pts[42] = new Point3D(0.403548, 0.0, 0.937864);
            pts[43] = new Point3D(0.489955, 0.830237, 0.33629);
            pts[44] = new Point3D(0.505832, -0.375774, 0.803348);
            pts[45] = new Point3D(0.521710, 0.418215, -0.771593);
            pts[46] = new Point3D(0.579632, 0.333333, 0.771593);
            pts[47] = new Point3D(0.583675, 0.692896, -0.470806);
            pts[48] = new Point3D(0.602051, -0.290893, -0.771593);
            pts[49] = new Point3D(0.657475, -0.597996, -0.502561);
            pts[50] = new Point3D(0.722234, -0.692896, 0.201774);
            pts[51] = new Point3D(0.749174, 0.0848813, -0.688458);
            pts[52] = new Point3D(0.784200, -0.418215, 0.502561);
            pts[53] = new Point3D(0.802576, 0.597996, 0.201774);
            pts[54] = new Point3D(0.849436, 0.529326, -0.201774);
            pts[55] = new Point3D(0.858000, 0.290893, 0.470806);
            pts[56] = new Point3D(0.860021, -0.529326, -0.150394);
            pts[57] = new Point3D(0.951720, 0.153552, -0.33629);
            pts[58] = new Point3D(0.960284, -0.0848813, 0.33629);
            pts[59] = new Point3D(1.007140, -0.153552, -0.067258);

            for (int i = 0; i < 60; i++)
            {
                pts[i] = new Point3D(pts[i].X * SideLength, pts[i].Y * SideLength, pts[i].Z * SideLength);
                pts[i] += (Vector3D)Center;
            }

            return pts;
        }

    }
}
