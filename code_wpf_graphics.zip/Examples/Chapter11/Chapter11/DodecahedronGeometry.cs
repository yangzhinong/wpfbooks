﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;

namespace Geometries
{
    public class DodecahedronGeometry
    {
        // Define private fields:
        private double sideLength = 1.0;
        private Point3D center = new Point3D();

        // Define public properties:
        public double SideLength
        {
            get { return sideLength; }
            set { sideLength = value; }
        }

        public Point3D Center
        {
            get { return center; }
            set { center = value; }
        }

        // Get-only property generates MeshGeometry3D object:
        public MeshGeometry3D Mesh3D
        {
            get { return GetMesh3D(); }
        }

        private MeshGeometry3D GetMesh3D()
        {
            MeshGeometry3D mesh = new MeshGeometry3D();

            Point3D[] pts = new Point3D[20];
            double phi = 0.5 * (1 + Math.Sqrt(5.0));
            double phi1 = 1.0 / phi;
            phi *= SideLength;
            phi1 *= SideLength;

            pts[0] = new Point3D(0, phi1, phi);
            pts[1] = new Point3D(0, -phi1, phi);
            pts[2] = new Point3D(SideLength, SideLength, SideLength);
            pts[3] = new Point3D(-SideLength, SideLength, SideLength);
            pts[4] = new Point3D(-SideLength, -SideLength, SideLength);
            pts[5] = new Point3D(SideLength, -SideLength, SideLength);
            pts[6] = new Point3D(phi, 0, phi1);
            pts[7] = new Point3D(-phi, 0, phi1);
            pts[8] = new Point3D(phi1, phi, 0);
            pts[9] = new Point3D(-phi1, phi, 0);
            pts[10] = new Point3D(-phi1, -phi, 0);
            pts[11] = new Point3D(phi1, -phi, 0);
            pts[12] = new Point3D(phi, 0, -phi1);
            pts[13] = new Point3D(-phi, 0, -phi1);
            pts[14] = new Point3D(SideLength, SideLength, -SideLength);
            pts[15] = new Point3D(-SideLength, SideLength, -SideLength);
            pts[16] = new Point3D(-SideLength, -SideLength, -SideLength);
            pts[17] = new Point3D(SideLength, -SideLength, -SideLength);
            pts[18] = new Point3D(0, phi1, -phi);
            pts[19] = new Point3D(0, -phi1, -phi);

            for (int i = 0; i < 20; i++)
                pts[i] += (Vector3D)Center;

            // Face 1 (0,1,5,6,2):
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[6]);

            mesh.TriangleIndices.Add(0);
            mesh.TriangleIndices.Add(1);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(1);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(2);
            mesh.TriangleIndices.Add(3);
            mesh.TriangleIndices.Add(4);

            // Face 2 (0,1,4,7,3):
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[7]);

            mesh.TriangleIndices.Add(5);
            mesh.TriangleIndices.Add(7);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(5);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(6);
            mesh.TriangleIndices.Add(9);
            mesh.TriangleIndices.Add(8);

            // Face 3 (0,2,8,9,3):
            mesh.Positions.Add(pts[0]);
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[9]);

            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(11);
            mesh.TriangleIndices.Add(13);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(13);
            mesh.TriangleIndices.Add(14);
            mesh.TriangleIndices.Add(10);
            mesh.TriangleIndices.Add(14);
            mesh.TriangleIndices.Add(12);

            // Face 4 (1,4,10,11,5):
            mesh.Positions.Add(pts[1]);
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[11]);

            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(16);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(15);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(17);
            mesh.TriangleIndices.Add(17);
            mesh.TriangleIndices.Add(18);
            mesh.TriangleIndices.Add(19);

            // Face 5 (2,6,12,14,8):
            mesh.Positions.Add(pts[2]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[12]);
            mesh.Positions.Add(pts[14]);

            mesh.TriangleIndices.Add(20);
            mesh.TriangleIndices.Add(21);
            mesh.TriangleIndices.Add(22);
            mesh.TriangleIndices.Add(21);
            mesh.TriangleIndices.Add(24);
            mesh.TriangleIndices.Add(22);
            mesh.TriangleIndices.Add(21);
            mesh.TriangleIndices.Add(23);
            mesh.TriangleIndices.Add(24);

            // Face 6 (3,9,15,13,7):
            mesh.Positions.Add(pts[3]);
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[15]);

            mesh.TriangleIndices.Add(25);
            mesh.TriangleIndices.Add(27);
            mesh.TriangleIndices.Add(26);
            mesh.TriangleIndices.Add(26);
            mesh.TriangleIndices.Add(27);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(28);
            mesh.TriangleIndices.Add(27);
            mesh.TriangleIndices.Add(29);

            // Face 7 (4,7,13,16,10):
            mesh.Positions.Add(pts[4]);
            mesh.Positions.Add(pts[7]);
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[16]);

            mesh.TriangleIndices.Add(30);
            mesh.TriangleIndices.Add(31);
            mesh.TriangleIndices.Add(32);
            mesh.TriangleIndices.Add(32);
            mesh.TriangleIndices.Add(31);
            mesh.TriangleIndices.Add(34);
            mesh.TriangleIndices.Add(34);
            mesh.TriangleIndices.Add(31);
            mesh.TriangleIndices.Add(33);

            // Face 8 (5,11,17,12,6):
            mesh.Positions.Add(pts[5]);
            mesh.Positions.Add(pts[6]);
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[12]);
            mesh.Positions.Add(pts[17]);

            mesh.TriangleIndices.Add(35);
            mesh.TriangleIndices.Add(37);
            mesh.TriangleIndices.Add(39);
            mesh.TriangleIndices.Add(35);
            mesh.TriangleIndices.Add(39);
            mesh.TriangleIndices.Add(38);
            mesh.TriangleIndices.Add(35);
            mesh.TriangleIndices.Add(38);
            mesh.TriangleIndices.Add(36);

            // Face 9 (8,14,18,15,9):
            mesh.Positions.Add(pts[8]);
            mesh.Positions.Add(pts[9]);
            mesh.Positions.Add(pts[14]);
            mesh.Positions.Add(pts[15]);
            mesh.Positions.Add(pts[18]);

            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(42);
            mesh.TriangleIndices.Add(44);
            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(44);
            mesh.TriangleIndices.Add(43);
            mesh.TriangleIndices.Add(40);
            mesh.TriangleIndices.Add(43);
            mesh.TriangleIndices.Add(41);

            // Face 10 (10,16,19,17,11):
            mesh.Positions.Add(pts[10]);
            mesh.Positions.Add(pts[11]);
            mesh.Positions.Add(pts[16]);
            mesh.Positions.Add(pts[17]);
            mesh.Positions.Add(pts[19]);

            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(47);
            mesh.TriangleIndices.Add(49);
            mesh.TriangleIndices.Add(45);
            mesh.TriangleIndices.Add(49);
            mesh.TriangleIndices.Add(46);
            mesh.TriangleIndices.Add(46);
            mesh.TriangleIndices.Add(49);
            mesh.TriangleIndices.Add(48);

            // Face 11 (12,17,19,18,14):
            mesh.Positions.Add(pts[12]);
            mesh.Positions.Add(pts[14]);
            mesh.Positions.Add(pts[17]);
            mesh.Positions.Add(pts[18]);
            mesh.Positions.Add(pts[19]);

            mesh.TriangleIndices.Add(50);
            mesh.TriangleIndices.Add(52);
            mesh.TriangleIndices.Add(54);
            mesh.TriangleIndices.Add(50);
            mesh.TriangleIndices.Add(54);
            mesh.TriangleIndices.Add(53);
            mesh.TriangleIndices.Add(50);
            mesh.TriangleIndices.Add(53);
            mesh.TriangleIndices.Add(51);

            // Face 12 (13,15,18,19,16):
            mesh.Positions.Add(pts[13]);
            mesh.Positions.Add(pts[15]);
            mesh.Positions.Add(pts[16]);
            mesh.Positions.Add(pts[18]);
            mesh.Positions.Add(pts[19]);

            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(56);
            mesh.TriangleIndices.Add(58);
            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(58);
            mesh.TriangleIndices.Add(59);
            mesh.TriangleIndices.Add(55);
            mesh.TriangleIndices.Add(59);
            mesh.TriangleIndices.Add(57);

            mesh.Freeze();
            return mesh;
        }
       
    }
}


