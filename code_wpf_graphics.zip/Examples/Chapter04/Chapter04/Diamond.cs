using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomRing
{
    public class Diamond : Shape
    {
        protected PathGeometry pg;
        PathFigure pf;
        PolyLineSegment pls;

        public Diamond()
        {
            pg = new PathGeometry();
            pf = new PathFigure();
            pls = new PolyLineSegment();
            pg.Figures.Add(pf);
        }

        // Specify the center of the diamond
        public static readonly DependencyProperty CenterProperty =
            DependencyProperty.Register("Center", typeof(Point), typeof(Diamond),
            new FrameworkPropertyMetadata(new Point(20.0, 20.0),
            FrameworkPropertyMetadataOptions.AffectsMeasure));
        public Point Center
        {
            set { SetValue(CenterProperty, value); }
            get { return (Point)GetValue(CenterProperty); }
        }

        // Specify the size of he diamond:
        public static readonly DependencyProperty SizeXProperty =
            DependencyProperty.Register("SizeX", typeof(double), typeof(Diamond),
            new FrameworkPropertyMetadata(10.0,
            FrameworkPropertyMetadataOptions.AffectsMeasure));
        public double SizeX
        {
            set { SetValue(SizeXProperty, value); }
            get { return (double)GetValue(SizeXProperty); }
        }

        protected override Geometry DefiningGeometry
        {
            get
            {
                pf.StartPoint = new Point(Center.X - SizeX / 2, Center.Y);
                pls.Points.Add(new Point(Center.X, Center.Y - SizeX / 2));
                pls.Points.Add(new Point(Center.X + SizeX / 2, Center.Y));
                pls.Points.Add(new Point(Center.X, Center.Y + SizeX / 2));
                pls.Points.Add(new Point(Center.X - SizeX / 2, Center.Y));
                pf.Segments.Add(pls);
                pf.IsClosed = true;
                pg.FillRule = FillRule.Nonzero;
                return pg;
            }
        }
    }
}
