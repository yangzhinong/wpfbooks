using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Chapter04
{
    /// <summary>
    /// Interaction logic for GeometryGroupExample.xaml
    /// </summary>
    
    public partial class AnimateBezierCurve : Window
    {
        public AnimateBezierCurve()
        {
            InitializeComponent();
        }
    }
}