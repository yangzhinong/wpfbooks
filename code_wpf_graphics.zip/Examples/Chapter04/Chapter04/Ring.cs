using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace CustomRing
{
    public class Ring : Shape
    {
        protected CombinedGeometry cg;
        EllipseGeometry egIn;
        EllipseGeometry egOut;

        public Ring()
        {
            cg = new CombinedGeometry();
            egIn = new EllipseGeometry();
            egOut = new EllipseGeometry();
            cg.Geometry1 = egOut;
            cg.Geometry2 = egIn;
        }

        // Specify the center of the ring shape
        public static readonly DependencyProperty CenterProperty =
            DependencyProperty.Register("Center", typeof(Point), typeof(Ring),
            new FrameworkPropertyMetadata(new Point(20.0, 20.0),
            FrameworkPropertyMetadataOptions.AffectsMeasure));
        public Point Center
        {
            set { SetValue(CenterProperty, value); }
            get { return (Point)GetValue(CenterProperty); }
        }

        // Specify the radiusX of the inner ellipse:
        public static readonly DependencyProperty RadiusInXProperty =
            DependencyProperty.Register("RadiusInX", typeof(double), typeof(Ring),
            new FrameworkPropertyMetadata(10.0,
            FrameworkPropertyMetadataOptions.AffectsMeasure));
        public double RadiusInX
        {
            set { SetValue(RadiusInXProperty, value); }
            get { return (double)GetValue(RadiusInXProperty); }
        }

        // Specify the radiusY of the inner ellipse:
        public static readonly DependencyProperty RadiusInYProperty =
            DependencyProperty.Register("RadiusInY", typeof(double), typeof(Ring),
            new FrameworkPropertyMetadata(10.0,
            FrameworkPropertyMetadataOptions.AffectsMeasure));
        public double RadiusInY
        {
            set { SetValue(RadiusInYProperty, value); }
            get { return (double)GetValue(RadiusInYProperty); }
        }

        // Specify the radiusX of the outer ellipse:
        public static readonly DependencyProperty RadiusOutXProperty =
            DependencyProperty.Register("RadiusOutX", typeof(double), typeof(Ring),
            new FrameworkPropertyMetadata(10.0,
            FrameworkPropertyMetadataOptions.AffectsMeasure));
        public double RadiusOutX
        {
            set { SetValue(RadiusOutXProperty, value); }
            get { return (double)GetValue(RadiusOutXProperty); }
        }

        // Specify the radiusY of the outer ellipse:
        public static readonly DependencyProperty RadiusOutYProperty =
            DependencyProperty.Register("RadiusOutY", typeof(double), typeof(Ring),
            new FrameworkPropertyMetadata(10.0,
            FrameworkPropertyMetadataOptions.AffectsMeasure));
        public double RadiusOutY
        {
            set { SetValue(RadiusOutYProperty, value); }
            get { return (double)GetValue(RadiusOutYProperty); }
        }
        
        // Gets a value that represents the geometry of the ring:
        protected override Geometry DefiningGeometry
        {
            get
            {
                cg.GeometryCombineMode = GeometryCombineMode.Xor;
                egIn.Center = Center;
                egIn.RadiusX = RadiusInX;
                egIn.RadiusY = RadiusInY;
                egOut.Center = Center;
                egOut.RadiusX = RadiusOutX;
                egOut.RadiusY = RadiusOutY;
                return cg;
            }
        }
    }
}
