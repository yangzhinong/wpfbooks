﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;
using _3DTools;

namespace Chapter10
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class SimpleTriangle : Window
    {
        public SimpleTriangle()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
