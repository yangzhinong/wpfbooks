﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using Geometries;

namespace Shapes
{
    public class Icosahedron : UIElement3D
    {
        protected override void OnUpdateModel()
        {
            GeometryModel3D model = new GeometryModel3D();
            IcosahedronGeometry geometry = new IcosahedronGeometry();
            geometry.SideLength = SideLength;
            geometry.Center = Center;
            model.Geometry = geometry.Mesh3D;
            model.Material = Material;
            Model = model;
        }

        // The Model property for the model:
        private static readonly DependencyProperty ModelProperty =
            DependencyProperty.Register("Model",
                                        typeof(Model3D),
                                        typeof(Icosahedron),
                                        new PropertyMetadata(ModelPropertyChanged));

        private static void ModelPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Icosahedron icosahedron = (Icosahedron)d;
            icosahedron.Visual3DModel = (Model3D)e.NewValue;
        }

        private Model3D Model
        {
            get { return (Model3D)GetValue(ModelProperty); }
            set { SetValue(ModelProperty, value); }
        }

        // The material of the model:
        public static readonly DependencyProperty MaterialProperty =
            DependencyProperty.Register("Material",
                                        typeof(Material),
                                        typeof(Icosahedron),
                                        new PropertyMetadata(new DiffuseMaterial(Brushes.Blue), PropertyChanged));

        public Material Material
        {
            get { return (Material)GetValue(MaterialProperty); }
            set { SetValue(MaterialProperty, value); }
        }

        // The side length of the model:
        public static readonly DependencyProperty SideLengthProperty =
            DependencyProperty.Register("SideLength",
                                        typeof(double),
                                        typeof(Icosahedron),
                                        new PropertyMetadata(1.0, PropertyChanged));

        public double SideLength
        {
            get { return (double)GetValue(SideLengthProperty); }
            set { SetValue(SideLengthProperty, value); }
        }

        // The center of the model:
        public static readonly DependencyProperty CenterProperty =
            DependencyProperty.Register("Center",
                                        typeof(Point3D),
                                        typeof(Icosahedron),
                                        new PropertyMetadata(new Point3D(0.0, 0.0, 0.0), PropertyChanged));

        public Point3D Center
        {
            get { return (Point3D)GetValue(CenterProperty); }
            set { SetValue(CenterProperty, value); }
        }

        private static void PropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Icosahedron icosahedron = (Icosahedron)d;
            icosahedron.InvalidateModel();
        }
    }
}
