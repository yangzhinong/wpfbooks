﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using Geometries;

namespace Shapes
{
    public class Soccer : UIElement3D
    {
        protected override void OnUpdateModel()
        {
            if (IsDifferentMaterial == true)
            {
                Model3DGroup group = new Model3DGroup();
                SoccerGeometry geometry = new SoccerGeometry();
                geometry.SideLength = SideLength;
                geometry.Center = Center;

                GeometryModel3D pentagonModel = new GeometryModel3D();
                pentagonModel.Geometry = geometry.PentagonMesh3D;
                pentagonModel.Material = PentagonMaterial; 
                group.Children.Add(pentagonModel);

                GeometryModel3D hexagonModel = new GeometryModel3D();
                hexagonModel.Geometry = geometry.HexagonMesh3D;
                hexagonModel.Material = HexagonMaterial;
                group.Children.Add(hexagonModel);

                Model = group;
            }

            else if (IsDifferentMaterial == false)
            {
                GeometryModel3D model = new GeometryModel3D();
                SoccerGeometry geometry = new SoccerGeometry();
                geometry.SideLength = SideLength;
                geometry.Center = Center;
                model.Geometry = geometry.Mesh3D;
                model.Material = Material;
                Model = model;
            }    
        }

        // The Model property for the model:
        private static readonly DependencyProperty ModelProperty =
            DependencyProperty.Register("Model",
                                        typeof(Model3D),
                                        typeof(Soccer),
                                        new PropertyMetadata(ModelPropertyChanged));

        private static void ModelPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Soccer soccer = (Soccer)d;
            soccer.Visual3DModel = (Model3D)e.NewValue;
        }

        private Model3D Model
        {
            get { return (Model3D)GetValue(ModelProperty); }
            set { SetValue(ModelProperty, value); }
        }

        // The material of the entire model:
        public static readonly DependencyProperty MaterialProperty =
            DependencyProperty.Register("Material",
                                        typeof(Material),
                                        typeof(Soccer),
                                        new PropertyMetadata(new DiffuseMaterial(Brushes.Blue), PropertyChanged));

        public Material Material
        {
            get { return (Material)GetValue(MaterialProperty); }
            set { SetValue(MaterialProperty, value); }
        }

        // The material of the pentagons:
        public static readonly DependencyProperty PentagonMaterialProperty =
            DependencyProperty.Register("PentagonMaterial",
                                        typeof(Material),
                                        typeof(Soccer),
                                        new PropertyMetadata(new DiffuseMaterial(Brushes.Black), PropertyChanged));

        public Material PentagonMaterial
        {
            get { return (Material)GetValue(PentagonMaterialProperty); }
            set { SetValue(PentagonMaterialProperty, value); }
        }

        // The material of the hexagons:
        public static readonly DependencyProperty HexagonMaterialProperty =
            DependencyProperty.Register("HexagonMaterial",
                                        typeof(Material),
                                        typeof(Soccer),
                                        new PropertyMetadata(new DiffuseMaterial(Brushes.White), PropertyChanged));

        public Material HexagonMaterial
        {
            get { return (Material)GetValue(HexagonMaterialProperty); }
            set { SetValue(HexagonMaterialProperty, value); }
        }

        // The side length of the model:
        public static readonly DependencyProperty SideLengthProperty =
            DependencyProperty.Register("SideLength",
                                        typeof(double),
                                        typeof(Soccer),
                                        new PropertyMetadata(1.0, PropertyChanged));

        public double SideLength
        {
            get { return (double)GetValue(SideLengthProperty); }
            set { SetValue(SideLengthProperty, value); }
        }

        // The center of the model:
        public static readonly DependencyProperty CenterProperty =
            DependencyProperty.Register("Center",
                                        typeof(Point3D),
                                        typeof(Soccer),
                                        new PropertyMetadata(new Point3D(0.0, 0.0, 0.0), PropertyChanged));

        public Point3D Center
        {
            get { return (Point3D)GetValue(CenterProperty); }
            set { SetValue(CenterProperty, value); }
        }

        // The different material:
        public static readonly DependencyProperty IsDifferentMaterialProperty =
            DependencyProperty.Register("IsDifferentMaterial",
                                        typeof(bool),
                                        typeof(Soccer),
                                        new PropertyMetadata(false, PropertyChanged));

        public bool IsDifferentMaterial
        {
            get { return (bool)GetValue(IsDifferentMaterialProperty); }
            set { SetValue(IsDifferentMaterialProperty, value); }
        }

        private static void PropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Soccer soccer = (Soccer)d;
            soccer.InvalidateModel();
        }
    }
}
