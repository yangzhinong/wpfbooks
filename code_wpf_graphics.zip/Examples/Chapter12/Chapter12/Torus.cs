﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using Geometries;

namespace Shapes
{
    public class Torus : UIElement3D
    {
        protected override void OnUpdateModel()
        {
            GeometryModel3D model = new GeometryModel3D();
            TorusGeometry geometry = new TorusGeometry();
            geometry.R1 = R1;
            geometry.R2 = R2;
            geometry.UDiv = UDiv;
            geometry.VDiv = VDiv;
            geometry.Center = Center;
            model.Geometry = geometry.Mesh3D;
            model.Material = Material;
            Model = model;
        }

        // The Model property for the Torus:
        private static readonly DependencyProperty ModelProperty =
            DependencyProperty.Register("Model",
                                        typeof(Model3D),
                                        typeof(Torus),
                                        new PropertyMetadata(ModelPropertyChanged));

        private static void ModelPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Torus torus = (Torus)d;
            torus.Visual3DModel = (Model3D)e.NewValue;
        }

        private Model3D Model
        {
            get { return (Model3D)GetValue(ModelProperty); }
            set { SetValue(ModelProperty, value); }
        }

        // The material of the Torus:
        public static readonly DependencyProperty MaterialProperty =
            DependencyProperty.Register("Material",
                                        typeof(Material),
                                        typeof(Torus),
                                        new PropertyMetadata(new DiffuseMaterial(Brushes.Blue), PropertyChanged));

        public Material Material
        {
            get { return (Material)GetValue(MaterialProperty); }
            set { SetValue(MaterialProperty, value); }
        }

        // The radius of the Tube:
        public static readonly DependencyProperty R1Property =
            DependencyProperty.Register("R1",
                                        typeof(double),
                                        typeof(Torus),
                                        new PropertyMetadata(1.0, PropertyChanged));

        public double R1
        {
            get { return (double)GetValue(R1Property); }
            set { SetValue(R1Property, value); }
        }

        // The radius of the Torus:
        public static readonly DependencyProperty R2Property =
            DependencyProperty.Register("R2",
                                        typeof(double),
                                        typeof(Torus),
                                        new PropertyMetadata(0.3, PropertyChanged));

        public double R2
        {
            get { return (double)GetValue(R2Property); }
            set { SetValue(R2Property, value); }
        }

        // The UDiv of the Torus:
        public static readonly DependencyProperty UDivProperty =
            DependencyProperty.Register("UDiv",
                                        typeof(int),
                                        typeof(Torus),
                                        new PropertyMetadata(20, PropertyChanged));

        public int UDiv
        {
            get { return (int)GetValue(UDivProperty); }
            set { SetValue(UDivProperty, value); }
        }

        // The VDiv of the Torus:
        public static readonly DependencyProperty VDivProperty =
            DependencyProperty.Register("VDiv",
                                        typeof(int),
                                        typeof(Torus),
                                        new PropertyMetadata(20, PropertyChanged));

        public int VDiv
        {
            get { return (int)GetValue(VDivProperty); }
            set { SetValue(VDivProperty, value); }
        }

        // The center of the Torus:
        public static readonly DependencyProperty CenterProperty =
            DependencyProperty.Register("Center",
                                        typeof(Point3D),
                                        typeof(Torus),
                                        new PropertyMetadata(new Point3D(0.0, 0.0, 0.0), PropertyChanged));

        public Point3D Center
        {
            get { return (Point3D)GetValue(CenterProperty); }
            set { SetValue(CenterProperty, value); }
        }


        private static void PropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Torus torus = (Torus)d;
            torus.InvalidateModel();
        }
    }
}

