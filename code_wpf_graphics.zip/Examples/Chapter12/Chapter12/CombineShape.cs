﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using Geometries;

namespace Shapes
{
    class CombineShape : UIElement3D
    {
        protected override void OnUpdateModel()
        {
            Model3DGroup group = new Model3DGroup();
            TorusGeometry torus = new TorusGeometry();
            CylinderGeometry cylinder = new CylinderGeometry();

            GeometryModel3D torusModel = new GeometryModel3D();
            torus.R1 = 0.6 * Dimension;
            torus.R2 = 0.1 * Dimension;
            torus.Center = Center + new Vector3D(0, Dimension / 4, 0);
            torusModel.Geometry = torus.Mesh3D;
            torusModel.Material = TorusMaterial;
            group.Children.Add(torusModel);

            torusModel = new GeometryModel3D();
            torus.R1 = 0.65 * Dimension;
            torus.R2 = 0.2 * Dimension;
            torus.Center = Center + new Vector3D(0, -Dimension / 4, 0);
            torusModel.Geometry = torus.Mesh3D;
            torusModel.Material = TorusMaterial;
            group.Children.Add(torusModel);

            GeometryModel3D cylinderModel = new GeometryModel3D();
            cylinder.Rin = 0.4 * Dimension;
            cylinder.Rout = 0.5 * Dimension;
            cylinder.Height = 1.5 * Dimension;
            cylinder.Center = Center;
            cylinderModel.Geometry = cylinder.Mesh3D;
            cylinderModel.Material = CylinderMaterial;
            group.Children.Add(cylinderModel);

            Model = group;
        }

        // The Model property for the model:
        private static readonly DependencyProperty ModelProperty =
            DependencyProperty.Register("Model",
                                        typeof(Model3D),
                                        typeof(CombineShape),
                                        new PropertyMetadata(ModelPropertyChanged));

        private static void ModelPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CombineShape combine = (CombineShape)d;
            combine.Visual3DModel = (Model3D)e.NewValue;
        }

        private Model3D Model
        {
            get { return (Model3D)GetValue(ModelProperty); }
            set { SetValue(ModelProperty, value); }
        }

        // The material of the  cylinder model:
        public static readonly DependencyProperty CylinderMaterialProperty =
            DependencyProperty.Register("CylinderMaterial",
                                        typeof(Material),
                                        typeof(CombineShape),
                                        new PropertyMetadata(new DiffuseMaterial(Brushes.Blue), PropertyChanged));

        public Material CylinderMaterial
        {
            get { return (Material)GetValue(CylinderMaterialProperty); }
            set { SetValue(CylinderMaterialProperty, value); }
        }

        // The material of the  torus model:
        public static readonly DependencyProperty TorusMaterialProperty =
            DependencyProperty.Register("TorusMaterial",
                                        typeof(Material),
                                        typeof(CombineShape),
                                        new PropertyMetadata(new DiffuseMaterial(Brushes.Blue), PropertyChanged));

        public Material TorusMaterial
        {
            get { return (Material)GetValue(TorusMaterialProperty); }
            set { SetValue(TorusMaterialProperty, value); }
        }

        // The dimensionof the model:
        public static readonly DependencyProperty DimensionProperty =
            DependencyProperty.Register("Dimension",
                                        typeof(double),
                                        typeof(CombineShape),
                                        new PropertyMetadata(2.0, PropertyChanged));

        public double Dimension
        {
            get { return (double)GetValue(DimensionProperty); }
            set { SetValue(DimensionProperty, value); }
        }

        // The center of the model:
        public static readonly DependencyProperty CenterProperty =
            DependencyProperty.Register("Center",
                                        typeof(Point3D),
                                        typeof(CombineShape),
                                        new PropertyMetadata(new Point3D(0.0, 0.0, 0.0), PropertyChanged));

        public Point3D Center
        {
            get { return (Point3D)GetValue(CenterProperty); }
            set { SetValue(CenterProperty, value); }
        }

        private static void PropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CombineShape combine = (CombineShape)d;
            combine.InvalidateModel();
        }
    }
}
