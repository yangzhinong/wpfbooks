﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using Geometries;

namespace Shapes
{
    public class Cylinder : UIElement3D
    {
        protected override void OnUpdateModel()
        {
            GeometryModel3D model = new GeometryModel3D();
            CylinderGeometry geometry = new CylinderGeometry();
            geometry.Rin = Rin;
            geometry.Rout = Rout;
            geometry.Height = Height;
            geometry.ThetaDiv = ThetaDiv;
            geometry.Center = Center;
            model.Geometry = geometry.Mesh3D;
            model.Material = Material;
            Model = model;
        }

        // The Model property for the Cylinder:
        private static readonly DependencyProperty ModelProperty =
            DependencyProperty.Register("Model",
                                        typeof(Model3D),
                                        typeof(Cylinder),
                                        new PropertyMetadata(ModelPropertyChanged));

        private static void ModelPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Cylinder cylinder = (Cylinder)d;
            cylinder.Visual3DModel = (Model3D)e.NewValue;
        }

        private Model3D Model
        {
            get { return (Model3D)GetValue(ModelProperty); }
            set { SetValue(ModelProperty, value); }
        }

        // The material of the Cylinder:
        public static readonly DependencyProperty MaterialProperty =
            DependencyProperty.Register("Material",
                                        typeof(Material),
                                        typeof(Cylinder),
                                        new PropertyMetadata(new DiffuseMaterial(Brushes.Blue), PropertyChanged));

        public Material Material
        {
            get { return (Material)GetValue(MaterialProperty); }
            set { SetValue(MaterialProperty, value); }
        }

        // The inner radius of the Cylinder:
        public static readonly DependencyProperty RinProperty =
            DependencyProperty.Register("Rin",
                                        typeof(double),
                                        typeof(Cylinder),
                                        new PropertyMetadata(0.0, PropertyChanged));

        public double Rin
        {
            get { return (double)GetValue(RinProperty); }
            set { SetValue(RinProperty, value); }
        }

        // The outer radius of the Cylinder:
        public static readonly DependencyProperty RoutProperty =
            DependencyProperty.Register("Rout",
                                        typeof(double),
                                        typeof(Cylinder),
                                        new PropertyMetadata(1.0, PropertyChanged));

        public double Rout
        {
            get { return (double)GetValue(RoutProperty); }
            set { SetValue(RoutProperty, value); }
        }

        // The height of the Cylinder:
        public static readonly DependencyProperty HeightProperty =
            DependencyProperty.Register("Height",
                                        typeof(double),
                                        typeof(Cylinder),
                                        new PropertyMetadata(1.0, PropertyChanged));

        public double Height
        {
            get { return (double)GetValue(HeightProperty); }
            set { SetValue(HeightProperty, value); }
        }

        // The ThetaDiv of the Cylinder:
        public static readonly DependencyProperty ThetaDivProperty =
            DependencyProperty.Register("ThetaDiv",
                                        typeof(int),
                                        typeof(Cylinder),
                                        new PropertyMetadata(20, PropertyChanged));

        public int ThetaDiv
        {
            get { return (int)GetValue(ThetaDivProperty); }
            set { SetValue(ThetaDivProperty, value); }
        }

        // The center of the Cylinder:
        public static readonly DependencyProperty CenterProperty =
            DependencyProperty.Register("Center",
                                        typeof(Point3D),
                                        typeof(Cylinder),
                                        new PropertyMetadata(new Point3D(0.0, 0.0, 0.0), PropertyChanged));

        public Point3D Center
        {
            get { return (Point3D)GetValue(CenterProperty); }
            set { SetValue(CenterProperty, value); }
        }


        private static void PropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Cylinder cylinder = (Cylinder)d;
            cylinder.InvalidateModel();
        }
    }
}
