﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Chapter08
{
    public partial class MultipleCharts : Window
    {

        public MultipleCharts()
        {
            InitializeComponent();
            AddChart();
        }

        private void AddChart()
        {
            DataSeriesLineChartControl ds;
            double x, y;

            // Create chart1:
            ds = new DataSeriesLineChartControl();
            ds.LineColor = Brushes.Blue;
            ds.LineThickness = 2;
            for (int i = 0; i < 70; i++)
            {
                x = i / 5.0;
                y = Math.Sin(x);
                ds.LineSeries.Points.Add(new Point(x, y));
            }
            chart1.ControlDataCollection.DataList.Add(ds);
            chart1.ControlDataCollection.AddLines();

            // Create chart2:
            ds = new DataSeriesLineChartControl();
            ds.LineColor = Brushes.Red;
            ds.LinePattern = DataSeriesLineChartControl.LinePatternEnum.Dash;
            ds.LineThickness = 2;

            for (int i = 0; i < 70; i++)
            {
                x = i / 5.0;
                y = Math.Cos(x);
                ds.LineSeries.Points.Add(new Point(x, y));
            }
            chart2.ControlDataCollection.DataList.Add(ds);
            chart2.ControlDataCollection.AddLines();

            // Create chart3:
            ds = new DataSeriesLineChartControl();
            ds.LineColor = Brushes.Black;
            ds.LineThickness = 2;

            for (int i = 0; i < 70; i++)
            {
                x = i / 5.0;
                y = Math.Sin(x) * Math.Sin(x);
                ds.LineSeries.Points.Add(new Point(x, y));
            }
            chart3.ControlDataCollection.DataList.Add(ds);
            chart3.ControlDataCollection.AddLines();

            // Create chart4:
            ds = new DataSeriesLineChartControl();
            ds.LineColor = Brushes.DarkGreen;
            ds.LineThickness = 2;

            for (int i = 0; i < 70; i++)
            {
                x = i / 5.0;
                y = Math.Cos(x) * Math.Cos(x) * Math.Cos(x);
                ds.LineSeries.Points.Add(new Point(x, y));
            }
            chart4.ControlDataCollection.DataList.Add(ds);
            chart4.ControlDataCollection.AddLines();
        }
    }
}
