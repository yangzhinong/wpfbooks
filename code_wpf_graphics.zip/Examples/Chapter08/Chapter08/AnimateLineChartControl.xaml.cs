﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Chapter08
{
    public partial class AnimateLineChartControl : Window
    {
        private double dt = 0.1;
        private double time = 0.0;
        private DataSeriesLineChartControl ds;
        private Random rand = new Random();

        public AnimateLineChartControl()
        {
            InitializeComponent();
            AddChart();
            StartAnimation();
        }

        private void AddChart()
        {
            ds = new DataSeriesLineChartControl();
            ds.LineColor = Brushes.Blue;
            chart1.Xmin = 0;
            chart1.Xmax = 50 * dt;
            chart1.XTick = 10 * dt;

            for (time = 0; time < 50 * dt; time += dt)
            {
                ds.LineSeries.Points.Add(new Point(time, Math.Sin(time * rand.Next(0, 100))));
            }
            chart1.ControlDataCollection.DataList.Add(ds);
            chart1.ControlDataCollection.AddLines();
        }

        private void StartAnimation()
        {
            DoubleAnimation da = new DoubleAnimation();
            da.From = 50;
            da.To = 380;
            da.Duration = TimeSpan.FromSeconds(5);
            da.AutoReverse = true;
            da.RepeatBehavior = RepeatBehavior.Forever;
            chart1.BeginAnimation(LineChartControl.WidthProperty, da);

            da = new DoubleAnimation();
            da.From = 50;
            da.To = 330;
            da.Duration = TimeSpan.FromSeconds(5);
            da.AutoReverse = true;
            da.RepeatBehavior = RepeatBehavior.Forever;
            chart1.BeginAnimation(LineChartControl.HeightProperty, da);
        }
    }
}
