﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Chapter08
{
    /// <summary>
    /// Interaction logic for LineChartExample.xaml
    /// </summary>
    public partial class LineChartExample : Window
    {
        private ChartStyle cs;
        private DataCollection dc = new DataCollection();
        private DataSeries ds = new DataSeries();

        public LineChartExample()
        {
            InitializeComponent();
            AddChart();
        }

        private void AddChart()
        {
            cs = new ChartStyle();
            cs.ChartCanvas = chartCanvas;
            //cs.ResizeCanvas(500, 300);
            cs.Xmin = 0;
            cs.Xmax = 7;
            cs.Ymin = -1.1;
            cs.Ymax = 1.1;

            // Draw Sine curve:
            ds.LineColor = Brushes.Blue;
            //ds.LinePattern = DataSeries.LinePatternEnum.Solid;
            ds.LineThickness = 3;
            for (int i = 0; i < 70; i++)
            {
                double x = i / 5.0;
                double y = Math.Sin(x);
                ds.LineSeries.Points.Add(new Point(x, y));
            }
            dc.DataList.Add(ds);

            // Draw cosine curve:
            ds = new DataSeries();
            ds.LineColor = Brushes.Red;
            ds.LinePattern = DataSeries.LinePatternEnum.DashDot;
            ds.LineThickness = 3;

            for (int i = 0; i < 70; i++)
            {
                double x = i / 5.0;
                double y = Math.Cos(x);
                ds.LineSeries.Points.Add(new Point(x, y));
            }
            dc.DataList.Add(ds);
            dc.AddLines(chartCanvas, cs);
        }
    }
}
