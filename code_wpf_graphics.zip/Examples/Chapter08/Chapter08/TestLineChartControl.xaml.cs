﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Chapter08
{
    public partial class TestLineChartControl : Window
    {
        private DataSeriesLineChartControl ds;

        public TestLineChartControl()
        {
            InitializeComponent();
            AddChart();
        }

        private void AddChart()
        {
            // Draw Sine curve:
            ds = new DataSeriesLineChartControl();
            ds.LineColor = Brushes.Blue;
            ds.LineThickness = 3;
            for (int i = 0; i < 70; i++)
            {
                double x = i / 5.0;
                double y = Math.Sin(x);
                ds.LineSeries.Points.Add(new Point(x, y));
            }
            myLineChart.ControlDataCollection.DataList.Add(ds);

            // Draw cosine curve:
            ds = new DataSeriesLineChartControl();
            ds.LineColor = Brushes.Red;
            ds.LinePattern = DataSeriesLineChartControl.LinePatternEnum.DashDot;
            ds.LineThickness = 3;

            for (int i = 0; i < 70; i++)
            {
                double x = i / 5.0;
                double y = Math.Cos(x);
                ds.LineSeries.Points.Add(new Point(x, y));
            }
            myLineChart.ControlDataCollection.DataList.Add(ds);

            myLineChart.ControlDataCollection.AddLines();
        }
    }
}
