using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace Chapter06
{
    /// <summary>
    /// Interaction logic for SimpleAnimation.xaml
    /// </summary>

    public partial class SimpleAnimation : System.Windows.Window
    {

        public SimpleAnimation()
        {
            InitializeComponent();

            DoubleAnimation da = new DoubleAnimation();
            da.From = 0;
            da.To = 200;
            da.AutoReverse = true;
            da.Duration = TimeSpan.FromSeconds(5);
            da.RepeatBehavior = RepeatBehavior.Forever;
            rect1.BeginAnimation(Canvas.LeftProperty, da);
            rect1.BeginAnimation(Canvas.TopProperty, da);
        }
    }
}