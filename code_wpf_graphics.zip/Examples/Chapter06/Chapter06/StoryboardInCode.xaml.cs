using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace Chapter06
{
    public partial class StoryboardInCode : System.Windows.Window
    {
        public StoryboardInCode()
        {
            InitializeComponent();
            
            Storyboard sb = new Storyboard();
            //ColorAnimation ca1 = new ColorAnimation(Colors.Blue, Colors.Yellow,
            //     new Duration(new TimeSpan(0, 0, 10)));
            ColorAnimation ca1 = new ColorAnimation(Colors.Blue, Colors.Yellow,
                 TimeSpan.FromSeconds(10));
            ca1.RepeatBehavior = RepeatBehavior.Forever;
            ca1.AutoReverse = true;
            Storyboard.SetTargetName(ca1, "brush1");
            Storyboard.SetTargetProperty(ca1, new PropertyPath(SolidColorBrush.ColorProperty));
            
            ColorAnimation ca2 = new ColorAnimation(Colors.Red, Colors.Green,
                 new Duration(new TimeSpan(0, 0, 10)));
            ca2.RepeatBehavior = RepeatBehavior.Forever;
            ca2.AutoReverse = true;
            ca2.BeginTime = new TimeSpan(0, 0, 5);
            Storyboard.SetTargetName(ca2, "brush2");
            Storyboard.SetTargetProperty(ca2, new PropertyPath(SolidColorBrush.ColorProperty));
            
            sb.Children.Add(ca1);
            sb.Children.Add(ca2);
            sb.Begin(this);
        }
    }
}