﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Chapter06
{
    public class FreefallDoubleAnimation : DoubleAnimationBase
    {
        public static readonly DependencyProperty AccelerationProperty =
            DependencyProperty.Register("Acceleration", typeof(double),
            typeof(FreefallDoubleAnimation), new PropertyMetadata(9.8));

        public static readonly DependencyProperty FromProperty =
            DependencyProperty.Register("From",
                typeof(double?),
                typeof(FreefallDoubleAnimation),
                new PropertyMetadata(null));

        public static readonly DependencyProperty ToProperty =
            DependencyProperty.Register("To",
                typeof(double?),
                typeof(FreefallDoubleAnimation),
                new PropertyMetadata(null));

        public double Acceleration
        {
            get { return (double)GetValue(AccelerationProperty); }
            set { SetValue(AccelerationProperty, value); }
        }

        public double? From
        {
            get { return (double?)GetValue(FromProperty); }
            set { SetValue(FromProperty, value); }
        }

        public double? To
        {
            get { return (double?)GetValue(ToProperty); }
            set { SetValue(ToProperty, value); }
        }

        protected override double GetCurrentValueCore(double defaultOriginValue,
            double defaultDestinationValue, AnimationClock clock)
        {
            double returnValue;
            double time = clock.CurrentProgress.Value;
            double start = From != null ? (double)From : defaultOriginValue;
            double delta = To != null ? (double)To - start : defaultOriginValue - start;

            double t0 = Math.Sqrt(2 / Acceleration);
            if (time > t0)
                time = t0;
            returnValue = 0.5 * Acceleration * time * time;
            returnValue *= delta;
            returnValue = returnValue + start;
            return returnValue;
        }

        protected override Freezable CreateInstanceCore()
        {
            return new FreefallDoubleAnimation();
        }
    }
}
