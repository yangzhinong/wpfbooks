using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Chapter06
{
    public partial class RollingBall : System.Windows.Window
    {
        public RollingBall()
        {
            InitializeComponent();
            StartRolling();
        }

        private void StartRolling()
        {
            double nRotation = 360 * 450 / 2 / Math.PI / 25;

            // Constant speed:
            DoubleAnimation da = new DoubleAnimation(0, 450, TimeSpan.FromSeconds(5));
            da.RepeatBehavior = RepeatBehavior.Forever;
            da.AutoReverse = true;
            ellipse1.BeginAnimation(Canvas.LeftProperty, da);

            da = new DoubleAnimation(0, nRotation, TimeSpan.FromSeconds(5));
            da.RepeatBehavior = RepeatBehavior.Forever;
            da.AutoReverse = true;
            ellipse1Rotate.BeginAnimation(RotateTransform.AngleProperty, da);

            // Acceleration:
            da = new DoubleAnimation(0, 450, TimeSpan.FromSeconds(5));
            da.AccelerationRatio = 0.4;
            da.RepeatBehavior = RepeatBehavior.Forever;
            da.AutoReverse = true;
            ellipse2.BeginAnimation(Canvas.LeftProperty, da);

            da = new DoubleAnimation(0, nRotation, TimeSpan.FromSeconds(5));
            da.AccelerationRatio = 0.4;
            da.RepeatBehavior = RepeatBehavior.Forever;
            da.AutoReverse = true;
            ellipse2Rotate.BeginAnimation(RotateTransform.AngleProperty, da);

            // Deceleration:
            da = new DoubleAnimation(0, 450, TimeSpan.FromSeconds(5));
            da.DecelerationRatio = 0.6;
            da.RepeatBehavior = RepeatBehavior.Forever;
            da.AutoReverse = true;
            ellipse3.BeginAnimation(Canvas.LeftProperty, da);

            da = new DoubleAnimation(0, nRotation, TimeSpan.FromSeconds(5));
            da.DecelerationRatio = 0.6;
            da.RepeatBehavior = RepeatBehavior.Forever;
            da.AutoReverse = true;
            ellipse3Rotate.BeginAnimation(RotateTransform.AngleProperty, da);

            // Acceleration + Deceleration:
            da = new DoubleAnimation(0, 450, TimeSpan.FromSeconds(5));
            da.DecelerationRatio = 0.6;
            da.AccelerationRatio = 0.4;
            da.RepeatBehavior = RepeatBehavior.Forever;
            da.AutoReverse = true;
            ellipse4.BeginAnimation(Canvas.LeftProperty, da);

            da = new DoubleAnimation(0, nRotation, TimeSpan.FromSeconds(5));
            da.DecelerationRatio = 0.6;
            da.AccelerationRatio = 0.4;
            da.RepeatBehavior = RepeatBehavior.Forever;
            da.AutoReverse = true;
            ellipse4Rotate.BeginAnimation(RotateTransform.AngleProperty, da);
        }
    }
}