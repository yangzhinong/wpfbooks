using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Chapter06
{
    /// <summary>
    /// Interaction logic for ProjectileExample.xaml
    /// </summary>

    public partial class TimerAnimation : Window
    {
        double XMin = 0;
        double YMin = 0;
        double XMax = 100;
        double YMax = 50;
        double X0 = 10;
        double Y0 = 10;
        double Vx = 10;
        double Vy = 10;
        double Gravity = 9.81;
        double TimeDelay = 50;
        double time = 0;
        double dt = 0.1;
        DispatcherTimer timer = new DispatcherTimer();
        Polyline pl = new Polyline();

        public TimerAnimation()
        {
            InitializeComponent();
            pl.Stroke = Brushes.Blue;
            canvas1.Children.Add(pl);
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            time = 0;
            dt = 0.1;

            if (canvas1.Children.Count > 3)
                canvas1.Children.Remove(pl);
            
            pl = new Polyline();
            pl.Stroke = Brushes.Blue;
            canvas1.Children.Add(pl);
            timer = new DispatcherTimer();

            X0 = Double.Parse(tbX0.Text);
            Y0 = Double.Parse(tbY0.Text);
            Vx = Double.Parse(tbVx.Text);
            Vy = Double.Parse(tbVy.Text);
            TimeDelay = Double.Parse(tbTimeDelay.Text);
            Gravity = Double.Parse(tbGravity.Text);

            // Set the axis limits:
            double xm = 2 * Vx * Vy / Gravity;
            double ym = 0.5 * Vy * Vy / Gravity;
            /*xMin = X0 - 0.1 * xm;
            yMin = Y0 - 0.1 * ym;
            xMax = X0 + 1.1 * xm;
            yMax = Y0 + 1.1 * ym;*/

            double x1 = Math.Round(X0 + xm, 0);
            double y1 = Math.Round(Y0 + ym, 0);
            tbXMax.Text = "Maximum X Distance = " + x1.ToString() + "m";
            tbYMax.Text = "Maximum Y Distance = " + y1.ToString() + "m";
            
            timer.Interval = TimeSpan.FromMilliseconds(TimeDelay);
            timer.Tick += new EventHandler(timer_Tick);
            timer.Start();    
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            double x = X0 + Vx * time;
            double y = Y0 + Vy * time - 0.5 * Gravity * time * time;

            if (y >= Y0)
            {
                Canvas.SetLeft(ellipse, XNormalize(x));
                Canvas.SetTop(ellipse, YNormalize(y));
                pl.Points.Add(new Point(XNormalize(x) + 5, YNormalize(y) + 5));
            }
            else
            {
                timer.Stop();
                return;
            }
            time += dt;
        }

        private double XNormalize(double x)
        {
            double result = (x - XMin) *
                   canvas1.Width / (XMax - XMin);
            return result;
        }

        private double YNormalize(double y)
        {
            double result = canvas1.Height - (y - YMin) *
                canvas1.Height / (YMax - YMin);
            return result;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}