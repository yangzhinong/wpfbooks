using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Chapter06
{
    /// <summary>
    /// Interaction logic for CombineTransformAnimation.xaml
    /// </summary>

    public partial class CombineTransformAnimation : System.Windows.Window
    {

        public CombineTransformAnimation()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text = "You are clicking on " + btn1.Content;
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text = "You are clicking on " + btn2.Content;
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}