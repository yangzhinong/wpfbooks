using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Chapter06
{
    public partial class AnimationSpeed : Window
    {
        public AnimationSpeed()
        {
            InitializeComponent();
        }
    }
}