using System;
using System.Windows;

namespace Chapter07
{
    public class ODESolver
    {
        /*public delegate double Function(double x, double y, double t);
        public static double[] RK4(Function f1, Function f2, double t0, 
            double x0, double y0, double dt)
        {
            double xk1, xk2, xk3, xk4;
            double yk1, yk2, yk3, yk4;
            double t = t0;
            double x = x0;
            double y = y0;

            xk1 = dt * f1(x, y, t);
            yk1 = dt * f2(x, y, t);

            xk2 = dt * f1(x + xk1 / 2, y + yk1 / 2, t + dt / 2);
            yk2 = dt * f2(x + xk1 / 2, y + yk1 / 2, t + dt / 2);

            xk3 = dt * f1(x + xk2 / 2, y + yk2 / 2, t + dt / 2);
            yk3 = dt * f2(x + xk2 / 2, y + yk2 / 2, t + dt / 2);

            xk4 = dt * f1(x + xk3, y + yk3, t + dt);
            yk4 = dt * f2(x + xk3, y + yk3, t + dt);

            x += (xk1 + 2 * xk2 + 2 * xk3 + xk4) / 6;
            y += (yk1 + 2 * yk2 + 2 * yk3 + yk4) / 6;
            return new double[2] { x, y };
        }*/
        
        public delegate double Function(double[] x, double t);
        public static double[] RungeKutta4(Function[] f, double[] x0, double t0, double dt)
        {
            int n = x0.Length;
            double[] k1 = new double[n];
            double[] k2 = new double[n];
            double[] k3 = new double[n];
            double[] k4 = new double[n];

            double t = t0;
            double[] x1 = new double[n];
            double[] x = x0;

            for (int i = 0; i < n; i++)
                k1[i] = dt * f[i](x, t);

            for (int i = 0; i < n; i++)
                x1[i] = x[i] + k1[i] / 2;

            for (int i = 0; i < n; i++)
                k2[i] = dt * f[i](x1, t + dt / 2);

            for (int i = 0; i < n; i++)
                x1[i] = x[i] + k2[i] / 2;

            for (int i = 0; i < n; i++)
                k3[i] = dt * f[i](x1, t + dt / 2);

            for (int i = 0; i < n; i++)
                x1[i] = x[i] + k3[i];

            for (int i = 0; i < n; i++)
                k4[i] = dt * f[i](x1, t + dt);

            for (int i = 0; i < n; i++)
                x[i] += (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]) / 6;

            return x;
        }
    }
}
