using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Chapter07
{
    public partial class JuliaSet : System.Windows.Window
    {
        private double Xmin = -2;
        private double Xmax = 2;
        private double Ymin = -1;
        private double Ymax = 1;
        
        private int NIterations = 50;
        private double MaxRadius2 = 4;
        private double Cx0 = 1.1;
        private double Cy0 = 0;

        private int width = 3*128;
        private int height = 3* 128;
        private Shape rubberBand = null;
        private Point startPoint = new Point();
        Point endPoint = new Point();

        public JuliaSet()
        {
            InitializeComponent();
            InitializeJulia();
        }

        private void InitializeJulia()
        {
            tbCReal.Text = "1.1";
            tbCImag.Text = "0";
            tbIterations.Text = "50";
            tbRadius.Text = "2.0";
            tbXmin.Text = "-2.0";
            tbXmax.Text = "2.0";
            tbYmin.Text = "-1.0";
            tbYmax.Text = "1.0";

            MaxRadius2 = 4.0;
            Cx0 = 1.1;
            Cy0 = 0;
            NIterations = 50;
            Xmin = -2.0;
            Xmax = 2.0;
            Ymin = -1.0;
            Ymax = 1.0;
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            AddJuliaSet();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            InitializeJulia();
            AddJuliaSet();
        }

        private void canvasMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (!canvas.IsMouseCaptured)
            {
                startPoint = e.GetPosition(canvas);
                canvas.CaptureMouse();
            }
        }

        private void canvasMouseMove(object sender, MouseEventArgs e)
        {
            if (canvas.IsMouseCaptured)
            {
                endPoint = e.GetPosition(canvas);
                if (rubberBand == null)
                {
                    rubberBand = new Rectangle();
                    rubberBand.Stroke = Brushes.Red;
                    canvas.Children.Add(rubberBand);
                }

                double width1 = Math.Abs(startPoint.X - endPoint.X);
                double height1 = Math.Abs(startPoint.Y - endPoint.Y);
                double left1 = Math.Min(startPoint.X, endPoint.X);
                double top1 = Math.Min(startPoint.Y, endPoint.Y);
                rubberBand.Width = width1;
                rubberBand.Height = height1;
                Canvas.SetLeft(rubberBand, left1);
                Canvas.SetTop(rubberBand, top1);
            }
        }

        private void canvasMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            endPoint = e.GetPosition(canvas);
            if (endPoint.X > startPoint.X)
            {
                Xmin = Xmin + (Xmax - Xmin) * startPoint.X / width;
                Xmax = Xmin + (Xmax - Xmin) * endPoint.X / width;
            }
            else if (endPoint.X < startPoint.X)
            {
                Xmax = Xmin + (Xmax - Xmin) * startPoint.X / width;
                Xmin = Xmin + (Xmax - Xmin) * endPoint.X / width;
            }

            if (endPoint.Y > startPoint.Y)
            {
                Ymin = Ymin + (Ymax - Ymin) * startPoint.Y / height;
                Ymax = Ymin + (Ymax - Ymin) * endPoint.Y / height;

            }
            else if (endPoint.Y < startPoint.Y)
            {
                Ymax = Ymin + (Ymax - Ymin) * startPoint.Y / height;
                Ymin = Ymin + (Ymax - Ymin) * endPoint.Y / height;
            }

            tbXmin.Text = Xmin.ToString();
            tbXmax.Text = Xmax.ToString();
            tbYmin.Text = Ymin.ToString();
            tbYmax.Text = Ymax.ToString();

            byte[] pixelData = DrawJuliaSet();
            BitmapSource bmpSource = BitmapSource.Create(width, height, 96, 96,
                PixelFormats.Gray8, null, pixelData, width);
            showImage.Source = bmpSource; 

            if (rubberBand != null)
            {
                canvas.Children.Remove(rubberBand);
                rubberBand = null;
                canvas.ReleaseMouseCapture();
            }
        }

        private void AddJuliaSet()
        {
            Xmin = Double.Parse(tbXmin.Text);
            Xmax = Double.Parse(tbXmax.Text);
            Ymin = Double.Parse(tbYmin.Text);
            Ymax = Double.Parse(tbYmax.Text);
            Cx0 = Double.Parse(tbCReal.Text);
            Cy0 = Double.Parse(tbCImag.Text);
            NIterations = Int32.Parse(tbIterations.Text);
            MaxRadius2 = 2.0 * Double.Parse(tbRadius.Text);
            byte[] pixelData = DrawJuliaSet();
            BitmapSource bmpSource = BitmapSource.Create(width, height, 96, 96,
                PixelFormats.Gray8, null, pixelData, width);
            showImage.Source = bmpSource;
        }

        private byte[] DrawJuliaSet()
        {
            int looper;
            int cindex = 0;

            double cx, cy, dcx, dcy, x, y, x2, y2;

            dcx = (Xmax - Xmin) / (width - 1);
            dcy = (Ymax - Ymin) / (height - 1);
            byte[] pixelData = new byte[width * height];
            
            cy = Ymin;
            for (int i = 0; i < height; i++)
            {
                int iIndex = i * height;
                cx = Xmin;
                for (int j = 0; j < width; j++)
                {
                    x = cx;
                    y = cy;
                    x2 = x * x;
                    y2 = y * y;
                    looper = 1;

                    while (looper < NIterations && x2 + y2 < MaxRadius2)
                    {
                        x2 = x * x;
                        y2 = y * y;
                        y = 2 * y * x - Cy0;
                        x = x2 - y2 - Cx0;
                        looper += 1;
                    }
                    if (looper >= NIterations)
                    {
                        cindex = 1 + (255 * (int)(x2 + y2)) % 255;
                    }
                    else
                        cindex = 200;
                    pixelData[j + iIndex] = (byte)cindex;
                    
                    cx += dcx;
                }
                cy += dcy;
            }
            return pixelData;
        }
    }
}