using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;

namespace Chapter07
{
    public class Utility
    {
        public static double XNormalize(Canvas canvas, double x, double min, double max)
        {
            double result = (x - min) *
                   canvas.Width / (max - min);
            return result;
        }

        public static double YNormalize(Canvas canvas, double y, double min, double max)
        {
            double result = canvas.Height - (y - min) *
                canvas.Height / (max - min);
            return result;
        }
    }
}

