﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using System.Windows.Media.Animation;
using Shapes;

namespace Chapter14
{
    public partial class HitTestShape3D : Window
    {
        public HitTestShape3D()
        {
            InitializeComponent();
        }


        private void OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            Point mousePoint = e.GetPosition(viewport3d);
            HitTestResult result = VisualTreeHelper.HitTest(viewport3d, mousePoint);
            RayMeshGeometry3DHitTestResult mesh = result as RayMeshGeometry3DHitTestResult;
            Point3DAnimation pa = new Point3DAnimation();


            if (mesh != null)
            {
                // Get mesh coordinates:
                double x = Math.Round(mesh.PointHit.X, 3);
                double y = Math.Round(mesh.PointHit.Y, 3);
                double z = Math.Round(mesh.PointHit.Z, 3);
                Point3D pt = new Point3D(x, y, z);

                string text = "(" + pt.ToString() + ")";
                if (result.VisualHit == ellipsoid)
                {
                    text = "Ellipsoid (red): Mesh Point = " + text;
                    pa.From = ellipsoid.Center;
                    pa.To = pt;
                    pa.Duration = TimeSpan.FromSeconds(0.2);
                    pa.AutoReverse = true;
                    ellipsoid.BeginAnimation(Ellipsoid.CenterProperty, pa);
                }
                else if (result.VisualHit == torus)
                {
                    text = "Torus (green): Mesh Point = " + text;
                    pa.From = torus.Center;
                    pa.To = pt;
                    pa.Duration = TimeSpan.FromSeconds(0.2);
                    pa.AutoReverse = true;
                    torus.BeginAnimation(Torus.CenterProperty, pa);
                }

                textBlock.Text = text;
            }

        }
    }
}
