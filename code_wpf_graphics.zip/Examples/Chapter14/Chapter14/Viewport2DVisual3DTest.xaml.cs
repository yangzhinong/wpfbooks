﻿using System;
using System.Windows;
using System.Windows.Media;

namespace Chapter14
{
    /// <summary>
    /// Interaction logic for Viewport2DVisual3DTest.xaml
    /// </summary>
    public partial class Viewport2DVisual3DTest : Window
    {
        public Viewport2DVisual3DTest()
        {
            InitializeComponent();
        }

        private void FrontButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("I am a 2D button on the front surface.");
        }

        private void RightButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("I am a 2D button on the right surface.");
        }

        private void TopButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("I am a 2D button on the top surface.");
        }
    }
}
