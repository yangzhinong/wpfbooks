﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Media3D;
using Geometries;


namespace Chapter14
{
    public partial class HitTest3D : Window
    {
        public HitTest3D()
        {
            InitializeComponent();
        }

        private void OnMouseDown(object sender, MouseButtonEventArgs e)
        {
            Point mousePoint = e.GetPosition(viewport3d);          
            HitTestResult result = VisualTreeHelper.HitTest(viewport3d, mousePoint);
            RayMeshGeometry3DHitTestResult mesh = result as RayMeshGeometry3DHitTestResult;
            
            if (mesh != null)
            {
                // Get mesh coordinates:
                double x = Math.Round(mesh.PointHit.X, 4);
                double y = Math.Round(mesh.PointHit.Y, 4);
                double z = Math.Round(mesh.PointHit.Z, 4);
                Point3D pt = new Point3D(x, y, z);

                string text = "(" + pt.ToString() + ")";
                if (mesh.MeshHit == torusMesh.Geometry)
                    text = "Torus - Mesh Point = " + text;
                else if (mesh.MeshHit == sphereMesh.Geometry)
                    text = "Sphere: Mesh Point = " + text;
                textBlock.Text = text;
            }
        }
    }
}
